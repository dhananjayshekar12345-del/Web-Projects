/* ---------- IndexedDB Setup ---------- */
let db;
const DB_NAME = "TelemedicineDB";
const DB_VER = 1;

function initDB() {
  const req = indexedDB.open(DB_NAME, DB_VER);
  req.onupgradeneeded = e => {
    db = e.target.result;
    if (!db.objectStoreNames.contains("profiles")) {
      db.createObjectStore("profiles", { keyPath: "id", autoIncrement: true });
    }
    if (!db.objectStoreNames.contains("appointments")) {
      db.createObjectStore("appointments", { keyPath: "id", autoIncrement: true });
    }
    if (!db.objectStoreNames.contains("suggestions")) {
      db.createObjectStore("suggestions", { keyPath: "id", autoIncrement: true });
    }
  };
  req.onsuccess = e => { db = e.target.result; console.log("DB ready"); };
}
initDB();

/* ---------- Pages ---------- */
const pages = {};

pages.dashboard = `
  <h2>Profile</h2>
  <div class="form-group"><label>Name</label><input type="text" id="name"></div>
  <div class="form-group"><label>Query</label><input type="text" id="query"></div>
  <div class="form-group"><label>History</label><input type="text" id="history"></div>
  <div class="form-group"><label>Contact</label><input type="text" id="phone"></div>
  <div class="form-group"><label>Gender</label>
    <select id="gender"><option>M</option><option>F</option><option>O</option></select>
  </div>
  <button class="btn" id="saveProfile">Save Profile</button>
`;

pages.appointments = `
  <h2>Appointment Application</h2>
  <div class="form-group"><label>Name</label><input id="appt_name"></div>
  <div class="form-group"><label>Query</label><input id="appt_query"></div>
  <div class="form-group"><label>Contact</label><input id="appt_contact"></div>
  <div class="form-group"><label>Gender</label>
    <select id="appt_gender"><option>M</option><option>F</option><option>O</option></select>
  </div>
  <button class="btn" id="saveAppt">Save Appointment Offline</button>
  <button class="btn" id="viewAppt">View Offline Appointments</button>
  <ul id="apptList"></ul>
`;

pages.suggestions = `
  <h2>Daily Health Suggestions</h2>
  <div class="suggestion">
    <div class="card" data-type="water">
      <h3>💧</h3><p>Water</p>
      <div class="progress"><div class="fill"></div><span>0/8</span></div>
      <button class="btn mark" data-inc="1" data-max="8">Mark +1</button>
    </div>
    <div class="card" data-type="protein">
      <h3>🥩</h3><p>Protein</p>
      <div class="progress"><div class="fill"></div><span>0/60g</span></div>
      <button class="btn mark" data-inc="10" data-max="60">Mark +10g</button>
    </div>
    <div class="card" data-type="steps">
      <h3>🚶</h3><p>Steps</p>
      <div class="progress"><div class="fill"></div><span>0/10000</span></div>
      <button class="btn mark" data-inc="1000" data-max="10000">Mark +1000</button>
    </div>
    <div class="card" data-type="sleep">
      <h3>🛌</h3><p>Sleep</p>
      <div class="progress"><div class="fill"></div><span>0/8h</span></div>
      <button class="btn mark" data-inc="1" data-max="8">Mark +1h</button>
    </div>
    <div class="card" data-type="fruits">
      <h3>🍎</h3><p>Fruits</p>
      <div class="progress"><div class="fill"></div><span>0/5</span></div>
      <button class="btn mark" data-inc="1" data-max="5">Mark +1</button>
    </div>
    <div class="card" data-type="meditation">
      <h3>🧘</h3><p>Meditation</p>
      <div class="progress"><div class="fill"></div><span>0/30min</span></div>
      <button class="btn mark" data-inc="5" data-max="30">Mark +5min</button>
    </div>
  </div>
`;

pages.interaction = `
  <h2>Patient Interaction</h2>
  <select id="chatSelect">
    <option value="0">Rajesh Kumar</option>
    <option value="1">Meena Sharma</option>
  </select>
  <div id="chatBox"></div>
  <input id="chatInput" placeholder="Type message...">
  <button class="btn" id="sendMsg">Send</button>

  <h3>Video Call (Demo)</h3>
  <video id="localVideo" autoplay muted playsinline></video>
  <video id="remoteVideo" autoplay playsinline></video><br>
  <button class="btn" id="startCam">Start Camera</button>
  <button class="btn" id="stopCam">Stop Camera</button>
  <button class="btn" id="simulateRemote">Simulate Remote</button>
`;

/* ---------- Render ---------- */
function renderPage(key) {
  const pageContent = document.getElementById("page-content");
  pageContent.innerHTML = pages[key] || "<h2>Not found</h2>";
  if (key === "dashboard") attachProfileHandlers();
  if (key === "appointments") attachAppointmentHandlers();
  if (key === "suggestions") attachSuggestionHandlers();
  if (key === "interaction") attachInteractionHandlers();
}

function showNotification(msg) {
  const box = document.getElementById("notifications");
  const list = document.getElementById("notifications-list");
  box.style.display = "block";
  const li = document.createElement("li");
  li.textContent = msg + " — " + new Date().toLocaleTimeString();
  list.prepend(li);
}

/* ---------- Handlers ---------- */
function el(id){ return document.getElementById(id); }

function attachProfileHandlers() {
  el("saveProfile").onclick = () => {
    const obj = { name: el("name").value, query: el("query").value, history: el("history").value, phone: el("phone").value, gender: el("gender").value };
    db.transaction("profiles","readwrite").objectStore("profiles").add(obj);
    showNotification("Profile saved");
  };
}

function attachAppointmentHandlers() {
  el("saveAppt").onclick = () => {
    const obj = { name: el("appt_name").value, query: el("appt_query").value, contact: el("appt_contact").value, gender: el("appt_gender").value, ts: new Date().toISOString() };
    db.transaction("appointments","readwrite").objectStore("appointments").add(obj);
    showNotification("Appointment saved");
  };

  el("viewAppt").onclick = () => {
    const list = el("apptList"); list.innerHTML = "";
    const tx = db.transaction("appointments","readonly").objectStore("appointments").getAll();
    tx.onsuccess = e => {
      e.target.result.forEach(a => {
        const li = document.createElement("li");
        li.textContent = `${a.name} (${a.gender}) - ${a.query} [${a.ts}]`;
        list.appendChild(li);
      });
    };
  };
}

function attachSuggestionHandlers() {
  const cards = document.querySelectorAll(".card");
  cards.forEach(card => {
    const btn = card.querySelector(".mark");
    const fill = card.querySelector(".fill");
    const span = card.querySelector("span");
    let current = 0;
    const max = parseInt(btn.dataset.max);
    const inc = parseInt(btn.dataset.inc);

    btn.onclick = () => {
      current = Math.min(current + inc, max);
      const percent = (current / max) * 100;
      fill.style.width = percent + "%";
      span.textContent = `${current}/${max}${span.textContent.replace(/^[0-9/]+/, "")}`;
      showNotification(card.dataset.type + " updated: " + current);
    };
  });
}

function attachInteractionHandlers() {
  const chatBox = el("chatBox");
  const input = el("chatInput");
  el("sendMsg").onclick = () => {
    const msg = input.value.trim();
    if (!msg) return;
    chatBox.innerHTML += `<div class="msg me">${msg}</div>`;
    input.value = "";
    setTimeout(()=> chatBox.innerHTML += `<div class="msg other">Noted</div>`, 1000);
    chatBox.scrollTop = chatBox.scrollHeight;
  };

  let stream;
  el("startCam").onclick = async () => {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      el("localVideo").srcObject = stream;
    } catch (err) { alert("Camera error: "+err.message); }
  };
  el("stopCam").onclick = () => { stream?.getTracks().forEach(t=>t.stop()); el("localVideo").srcObject = null; };
  el("simulateRemote").onclick = () => { el("remoteVideo").srcObject = el("localVideo").srcObject; };
}
