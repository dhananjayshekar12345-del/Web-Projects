// ✅ Hospital Wise Empty Datasets (Expand later)
const hospitalData = {
    "Apollo": [
        { name: "Rajesh Kumar", age: 50, disease: "Heart Issue" }
    ],
    "Fortis": [
        { name: "Sneha Gupta", age: 29, disease: "Fever" }
    ],
    "AIIMS": [
        { name: "Arjun Mehta", age: 33, disease: "Asthma" }
    ],
    "Manipal": [
        { name: "Neha Sharma", age: 41, disease: "Diabetes" }
    ]
};

// ✅ Load Data When Hospital Selected
function loadHospitalData() {
    let selected = document.getElementById("hospitalSelect").value;

    if (!selected) {
        document.getElementById("hospitalMsg").innerText = "";
        return;
    }

    patients = hospitalData[selected];
    loadPatients();
    renderPatientChart();

    document.getElementById("hospitalMsg").innerText =
        "✅ Loaded data for " + selected;
}

// ✅ Import CSV & Update Dashboard
function importCSV() {
    let file = document.getElementById("csvFile").files[0];
    if (!file) {
        alert("Please upload a CSV file!");
        return;
    }

    let reader = new FileReader();
    
    reader.onload = function(e) {
        let rows = e.target.result.split("\n");
        let newPatients = [];

        for (let i = 1; i < rows.length; i++) {
            if (!rows[i].trim()) continue;
            let data = rows[i].split(",");

            newPatients.push({
                name: data[0].trim(),
                age: parseInt(data[1].trim()),
                disease: data[2].trim()
            });
        }

        if (newPatients.length > 0) {
            patients = patients.concat(newPatients);
            loadPatients();
            renderPatientChart();
            document.getElementById("csvMsg").innerText =
                "✅ Cleaned Data Imported Successfully!";
        }
    };

    reader.readAsText(file);
}



