const patients = [
  { id: 1, name: "Mahesh Kumar", age: 45, disease: "Diabetes" },
  { id: 2, name: "Anjali Sharma", age: 34, disease: "Heart Disease" },
  { id: 3, name: "Rahul Verma", age: 29, disease: "Fever" },
  { id: 4, name: "Sita Devi", age: 64, disease: "BP" }
];

// COUNT DISEASES
const diseaseCounts = patients.reduce((acc, p) => {
  acc[p.disease] = (acc[p.disease] || 0) + 1;
  return acc;
}, {});

// DISEASE CHART
new Chart(document.getElementById("diseaseChart"), {
  type: 'pie',
  data: {
    labels: Object.keys(diseaseCounts),
    datasets: [{
      data: Object.values(diseaseCounts)
    }]
  }
});

// AGE CHART (Bar Graph)
new Chart(document.getElementById("ageChart"), {
  type: 'bar',
  data: {
    labels: patients.map(p => p.name),
    datasets: [{
      label: "Age",
      data: patients.map(p => p.age)
    }]
  }
});
