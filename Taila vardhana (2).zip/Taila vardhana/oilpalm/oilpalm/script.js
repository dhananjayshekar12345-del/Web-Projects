// --- Core Utilities ---
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const svgNS = "http://www.w3.org/2000/svg"; // SVG Namespace

// =========================================================
// 1. Language Rotator Functionality
// =========================================================
const welcomeElement = document.getElementById('welcome-message');
const messages = [
    { text: 'Welcome', lang: 'English' },
    { text: 'ನಮಸ್ತೆ', lang: 'Kannada' },
    { text: 'வணக்கம்', lang: 'Tamil' },
    { text: 'స్వాగతం', lang: 'Telugu' },
    { text: 'नमस्कार', lang: 'Hindi' },
    { text: 'Bienvenido', lang: 'Spanish' }
];

let messageIndex = 0;

function rotateWelcomeMessage() {
    const message = messages[messageIndex];
    if (welcomeElement) {
        welcomeElement.textContent = message.text;
        
        // Optional: Change color slightly for a better effect
        const colors = ['#73a942', '#5c8435', '#4a6b2c'];
        welcomeElement.style.color = colors[messageIndex % colors.length];
    }

    messageIndex = (messageIndex + 1) % messages.length;
}

// Start rotation every 3 seconds (3000ms)
setInterval(rotateWelcomeMessage, 3000);
// Initial call to set the first message immediately
document.addEventListener('DOMContentLoaded', rotateWelcomeMessage);


// =========================================================
// 2. Login/Profile Functionality
// =========================================================
const authButton = document.getElementById('auth-button');
const loginModal = document.getElementById('login-modal');
const closeButton = document.querySelector('.modal .close-button');
const loginForm = document.getElementById('login-form');
const profileDisplay = document.getElementById('profile-details');

let isLoggedIn = false;
let userName = "Priya M."; // Placeholder profile data

function updateAuthButton() {
    if (!authButton) return;

    if (isLoggedIn) {
        // Change to Profile button with simple animated pic (using an icon as an animated pic)
        authButton.innerHTML = '<i class="fas fa-user-circle animated-icon"></i> Profile';
        authButton.classList.remove('login-button');
        authButton.classList.add('profile-button');
        // Add a simple animation style for the icon
        if (!document.querySelector('style#pulse-animation')) {
            const style = document.createElement('style');
            style.id = 'pulse-animation';
            style.textContent = `
                @keyframes pulse {
                    0% { transform: scale(1); opacity: 1; }
                    50% { transform: scale(1.1); opacity: 0.8; }
                    100% { transform: scale(1); opacity: 1; }
                }
                .animated-icon {
                    animation: pulse 2s infinite;
                }
            `;
            document.head.appendChild(style);
        }

    } else {
        authButton.innerHTML = '<i class="fas fa-sign-in-alt"></i> Login';
        authButton.classList.remove('profile-button');
        authButton.classList.add('login-button');
        if (profileDisplay) profileDisplay.style.display = 'none'; // Hide profile details
    }
}

// Open modal on button click
if (authButton && loginModal && loginForm && profileDisplay) {
    authButton.onclick = function() {
        if (isLoggedIn) {
            // If logged in, show profile details in the modal
            loginForm.style.display = 'none';
            profileDisplay.innerHTML = `
                <h3>${userName}'s Profile</h3>
                <p><strong>Email:</strong> user.priya@seedintel.com</p>
                <p><strong>Region:</strong> Karnataka, India</p>
                <p><strong>Status:</strong> Verified Farmer</p>
                <button id="logout-button" class="action-button" style="margin-top: 15px;"><i class="fas fa-sign-out-alt"></i> Logout</button>
            `;
            profileDisplay.style.display = 'block';

            // Add event listener for logout button
            const logoutButton = document.getElementById('logout-button');
            if (logoutButton) {
                logoutButton.onclick = function() {
                    isLoggedIn = false;
                    updateAuthButton();
                    loginModal.style.display = 'none';
                    loginForm.style.display = 'block';
                };
            }

        } else {
            // If logged out, show the login form
            loginForm.style.display = 'block';
            profileDisplay.style.display = 'none';
        }
        loginModal.style.display = 'block';
    };
}

// Close modal on 'x' click
if (closeButton && loginModal) {
    closeButton.onclick = function() {
        loginModal.style.display = 'none';
    }
}

// Close modal when clicking outside of it
if (loginModal) {
    window.onclick = function(event) {
        if (event.target == loginModal) {
            loginModal.style.display = 'none';
        }
    }
}

// Handle login form submission (Front-end simulation only)
if (loginForm) {
    loginForm.onsubmit = function(event) {
        event.preventDefault(); // Prevent actual form submission
        
        // Simulate successful login
        setTimeout(() => {
            isLoggedIn = true;
            updateAuthButton();
            if (loginModal) loginModal.style.display = 'none';
            // Use a custom message box instead of alert()
            const loginMessage = document.createElement('div');
            loginMessage.className = 'fixed top-4 right-4 bg-green-500 text-white p-4 rounded-lg shadow-xl z-50';
            loginMessage.textContent = `Welcome back, ${userName}!`;
            document.body.appendChild(loginMessage);
            setTimeout(() => {
                loginMessage.remove();
            }, 3000);
        }, 500);
    }
}

// Initial button setup
document.addEventListener('DOMContentLoaded', updateAuthButton);


// =========================================================
// 3. Chatbot Pop-up Functionality
// =========================================================
const chatbotToggle = document.getElementById('chatbot-toggle');
const chatbotWindow = document.getElementById('chatbot-window');
const closeChatbot = document.querySelector('.close-chatbot');

if (chatbotToggle && chatbotWindow && closeChatbot) {
    chatbotToggle.onclick = function() {
        if (chatbotWindow.style.display === 'flex') {
            chatbotWindow.style.display = 'none';
        } else {
            chatbotWindow.style.display = 'flex';
        }
    };

    closeChatbot.onclick = function() {
        chatbotWindow.style.display = 'none';
    };
}


// =========================================================
// 4. KCC (Kisan Credit Card) Functionality
// =========================================================

// --- DOM Element References ---
const kccHasNo = document.getElementById('kcc-has-no');
const kccHasYes = document.getElementById('kcc-has-yes');
const kccNewSection = document.getElementById('kcc-new-section');
const kccExistingSection = document.getElementById('kcc-existing-section');
const kccCheckButton = document.getElementById('kcc-check');
const kccResetButton = document.getElementById('kcc-reset');
const kccResult = document.getElementById('kcc-result');
const kccContactButton = document.getElementById('kcc-contact');
const kccContactMsg = document.getElementById('kcc-contact-msg');
const kccCardDisplay = document.getElementById('kcc-card-display');

/**
 * Toggles the display of the 'New KCC' vs. 'Existing KCC' forms
 */
function toggleKccSections() {
    if (!kccNewSection || !kccExistingSection || !kccCheckButton || !kccCardDisplay) return;

    if (kccHasNo.checked) {
        kccNewSection.style.display = 'block';
        kccExistingSection.style.display = 'none';
        kccCheckButton.textContent = 'Check Eligibility';
        kccCardDisplay.style.display = 'none';
    } else {
        kccNewSection.style.display = 'none';
        kccExistingSection.style.display = 'block';
        kccCheckButton.textContent = 'Validate KCC';
        kccCardDisplay.style.display = 'block';
        renderKccCard(); // Show the simulated card for existing users
    }
    if (kccResult) kccResult.textContent = ''; // Clear previous results
}

/**
 * Renders a simulated 3D KCC card for visual appeal.
 */
function renderKccCard() {
    if (!kccCardDisplay) return;

    kccCardDisplay.innerHTML = `
        <div class="kcc-card3d">
            <div class="kcc-card-bank">Seed Intel Co-Op Bank</div>
            <div class="kcc-card-chip"></div>
            <div class="kcc-card-number">XXXX XXXX XXXX 4042</div>
            <div class="kcc-card-details">
                <div class="kcc-card-holder">Kisan Card Holder</div>
                <div class="kcc-card-valid">VALID THRU: 05/28</div>
            </div>
            <div class="kcc-card-logo">💳 KCC</div>
        </div>
    `;
}

/**
 * Handles the Eligibility Check or Validation logic (Demo).
 */
function handleKccCheck() {
    if (!kccResult) return;
    
    kccResult.className = 'mt-3 text-sm font-semibold';

    if (kccHasNo.checked) {
        // Eligibility Check Logic (DEMO)
        const land = parseFloat(document.getElementById('kcc-land').value);
        const income = parseFloat(document.getElementById('kcc-income').value);

        if (isNaN(land) || isNaN(income) || land <= 0 || income <= 50000) {
            kccResult.textContent = '❌ Preliminary check failed: You may need higher land holding/income. Consult official bank guidelines.';
            kccResult.style.color = 'red';
        } else if (land >= 1 && income >= 100000) {
            kccResult.textContent = '✅ You appear eligible! Your details meet the basic criteria. Proceed to official application.';
            kccResult.style.color = 'var(--primary-dark)';
        } else {
            kccResult.textContent = '⚠️ Check inconclusive. Please ensure all details are accurate and consult your bank.';
            kccResult.style.color = '#FFA500'; // Orange
        }

    } else {
        // Existing KCC Validation Logic (DEMO)
        const name = document.getElementById('kcc-existing-name').value;
        const age = document.getElementById('kcc-existing-age').value;
        if (name && age >= 18) {
             kccResult.textContent = `✅ Validation successful for ${name}. View your profile/scheme details on the bank portal.`;
             kccResult.style.color = 'var(--primary-dark)';
        } else {
            kccResult.textContent = '❌ Validation failed. Check name and age or contact support.';
            kccResult.style.color = 'red';
        }
    }
}

/**
 * Resets all KCC form fields and results.
 */
function handleKccReset() {
    // Clear inputs using dynamic lookup (safer when not all inputs exist)
    const inputs = ['kcc-name', 'kcc-land', 'kcc-income', 'kcc-existing-name', 'kcc-existing-age'];
    inputs.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });

    if (kccResult) kccResult.textContent = '';
    if (kccContactMsg) kccContactMsg.textContent = '';
    if (kccHasNo) kccHasNo.checked = true;
    toggleKccSections();
}

// --- KCC Event Listeners ---
document.addEventListener('DOMContentLoaded', () => {
    if (kccHasNo && kccHasYes) {
        kccHasNo.addEventListener('change', toggleKccSections);
        kccHasYes.addEventListener('change', toggleKccSections);
    }
    if (kccCheckButton) kccCheckButton.addEventListener('click', handleKccCheck);
    if (kccResetButton) kccResetButton.addEventListener('click', handleKccReset);

    if (kccContactButton) {
        kccContactButton.addEventListener('click', () => {
            if (kccContactMsg) {
                kccContactMsg.textContent = '📞 Initiating virtual contact setup... Please wait for an agent pop-up (Demo: Use the official bank website).';
                kccContactMsg.style.color = 'var(--primary-dark)';
            }
        });
    }
});


// =========================================================
// 5. Global Tab Navigation Control
// =========================================================

const tabLinks = document.querySelectorAll('.nav-primary .tab-link');
const tabContents = document.querySelectorAll('.main-content .tab-content');
const defaultTabId = 'tab-home'; // The ID of the default tab to show

/**
 * Handles the logic for switching between different functionality tabs 
 */
function switchTab(targetTabId) {
    // 1. Hide all content tabs
    tabContents.forEach(content => {
        content.style.display = 'none';
        content.classList.remove('active');
    });

    // 2. Remove 'active' class from all links
    tabLinks.forEach(link => {
        link.classList.remove('active');
    });

    // 3. Show the selected content tab
    const activeContent = document.getElementById(targetTabId);
    const activeLink = document.querySelector(`.nav-primary a[href="#${targetTabId}"]`);

    if (activeContent) {
        activeContent.style.display = 'block';
        activeContent.classList.add('active');
        // Scroll to the content for a smoother transition
        activeContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (activeLink) {
        activeLink.classList.add('active');
    }
        
    // Special handling for KCC tab initialization
    if (targetTabId === 'tab-kcc' && kccHasNo && kccHasYes) {
        toggleKccSections(); 
    }
    
    // Special handling for FFB Ledger to refresh data from server
    if (targetTabId === 'tab-ffb') {
        renderLedger();
    }
    
    // Special handling for Community Sim initialization
    if (targetTabId === 'tab-community') {
        resetPlantVisualDetailed();
        simLog('Simulator tab active.', 'info');
    }
}

// --- Event Listeners for Tabs ---
tabLinks.forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault(); // Stop default jump/refresh

        const targetId = this.getAttribute('href').substring(1); 
        switchTab(targetId);
    });
});

// --- Initial App Load State ---
document.addEventListener('DOMContentLoaded', () => {
    // Check URL hash for direct linking (e.g., app.com/#tab-kcc)
    const initialTab = window.location.hash.substring(1) || defaultTabId;
    
    // Ensure the initial tab is correctly set and displayed
    switchTab(initialTab);
});


/* ------------------------------------------------------------------- */
/* -------------------- 💰 GIB Planner (Finance) Logic -------------------- */
/* ------------------------------------------------------------------- */
let gibChart = null;

function handleGibCalc() {
    const crop = $('#gib-crop')?.value;
    const acres = parseFloat($('#gib-acre')?.value) || 0;
    const yieldPerAcre = parseFloat($('#gib-yield')?.value) || 0;
    const pricePerKg = parseFloat($('#gib-price')?.value) || 0;
    const out = $('#gib-output');

    if (!out) return;

    if (acres <= 0 || yieldPerAcre <= 0 || pricePerKg <= 0) {
        out.innerHTML = `<div class="text-sm" style="color:#b91c1c">Please enter valid positive values for all inputs.</div>`;
        if (gibChart) { gibChart.destroy(); gibChart = null; }
        return;
    }

    const estimatedKg = acres * yieldPerAcre;
    const estimatedRevenue = estimatedKg * pricePerKg;
    
    // Demo GIB Logic: Recommended Bridge is 35% of estimated revenue (min 20%, max 50%)
    const bridgeMin = Math.round(estimatedRevenue * 0.20);
    const bridgeMax = Math.round(estimatedRevenue * 0.50);
    const recommendedBridge = Math.round(Math.max(bridgeMin, Math.min(bridgeMax, estimatedRevenue * 0.35)));
    
    const retained = Math.max(0, Math.round(estimatedRevenue - recommendedBridge));

    out.innerHTML = `
        <div><strong>Crop:</strong> ${crop}</div>
        <div class="mt-2"><strong>Estimated Harvest:</strong> ${estimatedKg.toLocaleString()} kg</div>
        <div><strong>Estimated Revenue:</strong> ₹${Math.round(estimatedRevenue).toLocaleString()}</div>
        <div class="mt-2 text-green-700"><strong>Recommended Bridge Support (Demo):</strong> ₹${recommendedBridge.toLocaleString()}</div>
        <div class="muted-xs">(Range: ₹${bridgeMin.toLocaleString()} - ₹${bridgeMax.toLocaleString()})</div>
        <div class="mt-4"><canvas id="gib-chart" width="25" height="25"></canvas></div>
    `;
    
    const canvas = document.getElementById('gib-chart');
    if (!canvas) return;

    const labels = ['Bridge Support Amount', 'Farmer Retained Revenue'];
    const data = [recommendedBridge, retained];
    const bg = ['rgba(66,153,225,0.9)', 'rgba(72,187,120,0.9)'];

    if (gibChart) {
        gibChart.data.labels = labels;
        gibChart.data.datasets[0].data = data;
        gibChart.update();
    } else {
        const ctx = canvas.getContext('2d');
        // Ensure Chart.js is loaded via HTML before this runs
        if (typeof Chart !== 'undefined') {
            gibChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: bg,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'bottom' },
                        title: { display: true, text: 'Estimated Revenue Distribution (Demo)' }
                    }
                }
            });
        }
    }
}
 
function handleGibReset() {
    if ($('#gib-acre')) $('#gib-acre').value = '5';
    if ($('#gib-yield')) $('#gib-yield').value = '1200';
    if ($('#gib-price')) $('#gib-price').value = '65';
    if ($('#gib-output')) $('#gib-output').innerHTML = 'No calculation yet.';
    if (gibChart) { gibChart.destroy(); gibChart = null; }
}

// Attach GIB Listeners
document.addEventListener('DOMContentLoaded', () => {
    $('#btn-gib-calc')?.addEventListener('click', handleGibCalc);
    $('#btn-gib-reset')?.addEventListener('click', handleGibReset);
});


/* ------------------------------------------------------------------- */
/* -------------------- 📋 FFB Sales Ledger (Server-Side DB) -------------------- */
/* ------------------------------------------------------------------- */

/**
 * Fetches the ledger data from the server API.
 * @returns {Promise<Array>} The ledger data.
 */
async function getLedger() {
    try {
        const response = await fetch('/api/ffb/ledger');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const ledger = await response.json();
        return ledger;
    } catch (error) {
        console.error('Error fetching ledger data:', error);
        return []; // Return empty array on failure
    }
}

/**
 * Renders the ledger data fetched from the server into the table.
 */
async function renderLedger() {
    const listEl = $('#ledger-list');
    const summaryEl = $('#ledger-summary');
    if (!listEl || !summaryEl) return;

    listEl.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-gray-500">Loading sales data...</td></tr>';

    const ledger = await getLedger();
    listEl.innerHTML = '';
    
    let totalKg = 0;
    let totalRevenue = 0;
    let totalProfit = 0;

    if (ledger.length === 0) {
        listEl.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-gray-500">No sales entries found.</td></tr>';
        summaryEl.textContent = 'No data to summarize.';
        return;
    }

    ledger.forEach(entry => {
        const revenue = entry.kg * entry.price;
        const costTotal = entry.kg * entry.cost;
        const profit = revenue - costTotal;

        totalKg += entry.kg;
        totalRevenue += revenue;
        totalProfit += profit;

        const row = `
            <tr class="hover:bg-gray-50 text-sm">
                <td class="px-3 py-2 text-gray-900">${new Date(entry.timestamp).toLocaleDateString()}</td>
                <td class="px-3 py-2">${entry.kg.toLocaleString()}</td>
                <td class="px-3 py-2">${entry.destination}</td>
                <td class="px-3 py-2">₹${entry.price}</td>
                <td class="px-3 py-2">₹${entry.cost}</td>
                <td class="px-3 py-2 text-blue-600">₹${revenue.toLocaleString()}</td>
                <td class="px-3 py-2 ${profit >= 0 ? 'text-green-600' : 'text-red-600'}">₹${profit.toLocaleString()}</td>
            </tr>
        `;
        listEl.innerHTML += row;
    });

    summaryEl.innerHTML = `
        <i class="fas fa-chart-line text-lg mr-2"></i> **Total Sales:** ${totalKg.toLocaleString()} kg | 
        **Total Revenue:** ₹${totalRevenue.toLocaleString()} | 
        **Total Profit (Est.):** <span class="${totalProfit >= 0 ? 'text-green-700' : 'text-red-700'}">₹${totalProfit.toLocaleString()}</span>
    `;
}

/**
 * Handles adding a new ledger entry via a POST request to the server.
 */
async function handleAddLedgerEntry() {
    const kgInput = $('#ledger-kg');
    const destInput = $('#ledger-dest');
    const priceInput = $('#ledger-price');
    const costInput = $('#ledger-cost');

    const kg = parseFloat(kgInput?.value);
    const destination = destInput?.value.trim();
    const price = parseFloat(priceInput?.value);
    const cost = parseFloat(costInput?.value);

    if (isNaN(kg) || isNaN(price) || isNaN(cost) || kg <= 0 || price <= 0 || cost < 0 || !destination) {
        // Use a custom message box instead of alert()
        console.error('Validation Failed: Please enter valid, positive values.');
        return;
    }

    const newEntry = { kg, destination, price, cost };

    try {
        const response = await fetch('/api/ffb/ledger', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newEntry)
        });

        if (!response.ok) {
            throw new Error('Failed to add entry to ledger.');
        }

        // Success: Refresh the list
        renderLedger(); 

        // Clear inputs
        kgInput.value = '';
        destInput.value = '';
        priceInput.value = '';
        costInput.value = '';
    } catch (error) {
        console.error('Error adding ledger entry:', error);
    }
}

// Attach FFB Listener
document.addEventListener('DOMContentLoaded', () => {
    $('#btn-ledger-add')?.addEventListener('click', handleAddLedgerEntry);
    
    // Initial render when the FFB tab is active on load
    if ($('#tab-ffb')?.classList.contains('active')) {
        renderLedger();
    }
});


/* ------------------------------------------------------------------- */
/* -------------------- 🌱 Community Sim Logic (SVG & Animation) -------------------- */
/* ------------------------------------------------------------------- */

const CROP_PROFILES = {
    'Groundnut': { color: '#e76f51', needs: { sun: 0.8, water: 0.6, soil: 'sandy' }, yieldEffect: 1.0 },
    'Soybean': { color: '#2a9d8f', needs: { sun: 0.7, water: 0.7, soil: 'loam' }, yieldEffect: 1.1 },
    'Rapeseed-Mustard': { color: '#f7c59f', needs: { sun: 0.6, water: 0.5, soil: 'clay' }, yieldEffect: 0.9 },
    'Sunflower': { color: '#f4a261', needs: { sun: 1.0, water: 0.5, soil: 'loam' }, yieldEffect: 1.2 },
    'Sesamum (Til)': { color: '#bcb8b1', needs: { sun: 0.9, water: 0.4, soil: 'sandy' }, yieldEffect: 0.8 }
};

const simStageEl = $('#sim-stage');
const simRainLayer = $('#sim-rain-layer');
const simThunderEl = $('#sim-thunder');
const simBolt = $('#sim-bolt');
const simLogEl = $('#sim-log');
const simLabel = $('#sim-stage-label');
const simSunEl = $('#sim-sun');
const simCloud1 = $('#sim-cloud-1');
const simCloud2 = $('#sim-cloud-2');
const btnSimStart = $('#btn-sim-start');
const btnSimReset = $('#btn-sim-reset');

let simInterval = null;
let currentGrowth = 0; // 0 (seed) to 100 (mature)
let rainDrops = [];

function simLog(message, type = 'log') {
    if (!simLogEl) return;
    const d = new Date().toLocaleTimeString();
    let prefix = '🔵';
    if (type === 'error') prefix = '🔴';
    if (type === 'success') prefix = '🟢';
    if (type === 'info') prefix = '💡';
    
    simLogEl.innerHTML = `<div class="log-entry">${prefix} [${d}] ${message}</div>` + simLogEl.innerHTML;
    const logEntries = simLogEl.querySelectorAll('.log-entry');
    if (logEntries.length > 20) {
        logEntries[logEntries.length - 1].remove();
    }
}

/**
 * Creates the base SVG structure and the plant elements (stem, leaves, fruit).
 */
function createDetailedPlantSVG(crop) {
    if (!simStageEl) return;
    simStageEl.innerHTML = '';
    
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', '100%');
    svg.setAttribute('viewBox', '0 0 400 400');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.setAttribute('id', 'plant-svg');

    // 1. Soil Base
    const soil = document.createElementNS(svgNS, 'rect');
    soil.setAttribute('x', '0');
    soil.setAttribute('y', '350');
    soil.setAttribute('width', '400');
    soil.setAttribute('height', '50');
    soil.setAttribute('fill', '#997B66');
    svg.appendChild(soil);

    // 2. Stem Group
    const stemGroup = document.createElementNS(svgNS, 'g');
    stemGroup.setAttribute('id', 'plant-stem');
    const stemW = 6;
    for (let s = 0; s < 6; s++) {
        const seg = document.createElementNS(svgNS, 'rect');
        seg.setAttribute('x', `${200 - stemW / 2}`); // Center the stem
        seg.setAttribute('y', `${350 - (s + 1) * 50}`);
        seg.setAttribute('width', `${stemW}`);
        seg.setAttribute('height', '0'); // Starts hidden
        seg.setAttribute('fill', CROP_PROFILES[crop].color);
        seg.setAttribute('id', `stem-seg-${s}`);
        stemGroup.appendChild(seg);
    }
    svg.appendChild(stemGroup);
    
    // 3. Leaves Group
    const leaves = document.createElementNS(svgNS, 'g');
    leaves.setAttribute('id', 'plant-leaves');
    svg.appendChild(leaves);

    // 4. Fruit/Pod Group
    const fruit = document.createElementNS(svgNS, 'g');
    fruit.setAttribute('id', 'plant-fruit');
    svg.appendChild(fruit);

    simStageEl.appendChild(svg);
    updatePlantVisual(0, crop);
}

/**
 * Updates the visual growth of the plant based on currentGrowth (0-100).
 */
function updatePlantVisual(growth, crop) {
    if (!simStageEl) return;

    const stemSegments = $$('#plant-stem rect');
    const leavesGroup = $('#plant-leaves');
    const fruitGroup = $('#plant-fruit');
    
    if (stemSegments.length === 0 || !leavesGroup || !fruitGroup) return;

    // 1. Stem Growth (0% to 50%)
    const stemGrowth = Math.min(1, growth / 50);
    const visibleSegments = Math.floor(stemGrowth * 6);
    const segmentHeight = 50;
    
    stemSegments.forEach((seg, index) => {
        let h = 0;

        if (index < visibleSegments) {
            h = segmentHeight;
        } else if (index === visibleSegments) {
            h = (stemGrowth * 6 - visibleSegments) * segmentHeight;
        }

        seg.setAttribute('height', `${h}`);
        seg.setAttribute('y', `${350 - (index + 1) * segmentHeight + (segmentHeight - h)}`);
    });

    // 2. Leaf Growth (10% to 80%)
    const leafGrowth = Math.max(0, Math.min(1, (growth - 10) / 70));
    const maxLeaves = 4;
    leavesGroup.innerHTML = '';
    const stemHeight = 350 - (visibleSegments * 50);
    
    if (leafGrowth > 0) {
        for (let i = 0; i < maxLeaves; i++) {
            if (i < leafGrowth * maxLeaves) {
                const leaf = document.createElementNS(svgNS, 'polygon');
                const x = 200;
                const y = stemHeight - (i * 20) - 20; // Position leaves up the stem
                const size = 15 + (15 * leafGrowth);
                const color = CROP_PROFILES[crop].color.replace('#', '#') + 'AA';

                let points = "";
                if (i % 2 === 0) { // Left-side leaf
                    points = `${x},${y} ${x - size},${y - size * 0.5} ${x - size * 0.5},${y + size * 0.1}`;
                } else { // Right-side leaf
                    points = `${x},${y} ${x + size},${y - size * 0.5} ${x + size * 0.5},${y + size * 0.1}`;
                }

                leaf.setAttribute('points', points);
                leaf.setAttribute('fill', color);
                leaf.setAttribute('stroke', CROP_PROFILES[crop].color);
                leaf.setAttribute('stroke-width', '1');
                leavesGroup.appendChild(leaf);
            }
        }
    }

    // 3. Fruit/Podding (70% to 100%)
    const fruitGrowth = Math.max(0, Math.min(1, (growth - 70) / 30));
    fruitGroup.innerHTML = '';
    
    if (fruitGrowth > 0) {
        const numFruits = Math.ceil(fruitGrowth * 3);
        const podColor = '#FFD700';

        for (let i = 0; i < numFruits; i++) {
            const fruit = document.createElementNS(svgNS, 'circle');
            const size = 5 + (fruitGrowth * 5);
            fruit.setAttribute('cx', `${200 + (i - 1) * 15}`);
            fruit.setAttribute('cy', `${stemHeight - 50 - size}`); // Position fruit near the top
            fruit.setAttribute('r', `${size}`);
            fruit.setAttribute('fill', podColor);
            fruitGroup.appendChild(fruit);
        }
    }
    
    // Update label
    let stage = 'Seed';
    if (growth > 10) stage = 'Seedling';
    if (growth > 40) stage = 'Vegetative Growth';
    if (growth > 70) stage = 'Flowering & Podding';
    if (growth === 100) stage = 'Maturity (Ready for Harvest)';
    
    if (simLabel) simLabel.textContent = `${stage} (${Math.round(growth)}%) - ${crop}`;
}


/**
 * Runs the simulation loop.
 */
function runSimulation() {
    if (simInterval) clearInterval(simInterval);
    
    const crop = $('#sim-crop')?.value;
    const sunInput = $('#sim-sun')?.value;
    const waterInput = $('#sim-water')?.value;
    const soilInput = $('#sim-soil')?.value;
    
    if (!crop || !sunInput || !waterInput || !soilInput || !btnSimStart) return;

    const profile = CROP_PROFILES[crop];
    const targetSoil = profile.needs.soil;
    
    // --- Determine Growth Rate & Conditions ---
    let baseRate = 0.5;
    let conditionFactor = 1.0;
    
    // Sun impact
    const sunMap = { 'high': 1.0, 'medium': 0.8, 'low': 0.4 };
    const sunEffect = sunMap[sunInput] * (1 + (profile.needs.sun - 0.7)); 
    conditionFactor *= sunEffect;
    
    // Water impact
    const waterMap = { 'high': 0.8, 'medium': 1.0, 'low': 0.5 };
    const waterEffect = waterMap[waterInput] * (1 + (profile.needs.water - 0.7)); 
    conditionFactor *= waterEffect;
    
    // Soil impact
    const soilMatch = soilInput === targetSoil ? 1.2 : (soilInput === 'loam' ? 1.0 : 0.8);
    conditionFactor *= soilMatch;
    
    const growthRate = baseRate * Math.max(0.1, Math.min(1.5, conditionFactor));

    // --- Visual Effects Setup ---
    animateWeather(sunInput, waterInput);
    
    // --- Start Loop ---
    simLog(`Starting simulation for ${crop}. Growth Rate: ${growthRate.toFixed(2)}/tick.`, 'info');
    simLog(`Optimal Soil: ${targetSoil.toUpperCase()}. Current Soil: ${soilInput.toUpperCase()}.`);

    btnSimStart.disabled = true;
    
    simInterval = setInterval(() => {
        if (currentGrowth >= 100) {
            clearInterval(simInterval);
            simInterval = null;
            simLog(`Simulation Complete! ${crop} has reached maturity. Estimated yield potential: ${((growthRate / baseRate) * profile.yieldEffect).toFixed(2)}x base.`, 'success');
            btnSimStart.disabled = false;
            return;
        }

        currentGrowth = Math.min(100, currentGrowth + growthRate);
        updatePlantVisual(currentGrowth, crop);
        
        if (currentGrowth > 50 && sunInput === 'low' && Math.random() < 0.05) {
            simLog('Warning: Low sunlight reducing photosynthesis efficiency!', 'error');
        }

    }, 500); // Ticks every half second
}

/**
 * Handles the visual weather effects in the stage.
 */
function animateWeather(sunInput, waterInput) {
    if (simSunEl) simSunEl.style.display = sunInput === 'high' ? 'block' : 'none';
    
    if (simCloud1) simCloud1.style.opacity = sunInput === 'low' ? 1 : 0.6;
    if (simCloud2) simCloud2.style.opacity = sunInput === 'low' ? 1 : 0.6;

    if (waterInput === 'high') {
        startRain();
        if (Math.random() < 0.2) {
            startThunder();
        }
    } else {
        stopRain();
    }
}

function startRain() {
    if (!simRainLayer) return;
    simRainLayer.style.opacity = 1;
    if (rainDrops.length === 0) {
        for (let i = 0; i < 50; i++) {
            const drop = document.createElement('div');
            drop.className = 'rain-drop';
            drop.style.left = `${Math.random() * 400}px`;
            drop.style.animationDelay = `-${Math.random() * 2}s`;
            simRainLayer.appendChild(drop);
            rainDrops.push(drop);
        }
    }
}

function stopRain() {
    if (simRainLayer) simRainLayer.style.opacity = 0;
}

function startThunder() {
    if (!simThunderEl || !simBolt) return;
    simThunderEl.classList.add('flash');
    simBolt.classList.remove('hidden');
    
    setTimeout(() => {
        simThunderEl.classList.remove('flash');
        simBolt.classList.add('hidden');
    }, 500);
    simLog('Dramatic weather event: Thunderstorm passing over!', 'info');
}

/**
 * Resets the visual and simulation state.
 */
function resetPlantVisualDetailed() {
    if (simInterval) clearInterval(simInterval);
    simInterval = null;
    currentGrowth = 0;
    
    if (simStageEl) simStageEl.innerHTML = '';
    if (simLogEl) simLogEl.innerHTML = '';
    
    if (simRainLayer) simRainLayer.innerHTML = '';
    rainDrops = [];

    if (simLabel) simLabel.textContent = 'Idle';
    if (simSunEl) simSunEl.style.display = 'none';
    if (btnSimStart) btnSimStart.disabled = false;
    
    const initialCrop = $('#sim-crop')?.value || 'Groundnut';
    createDetailedPlantSVG(initialCrop);
    updatePlantVisual(0, initialCrop);
}

// --- Community Sim Event Listeners ---
document.addEventListener('DOMContentLoaded', () => {
    btnSimStart?.addEventListener('click', runSimulation);
    btnSimReset?.addEventListener('click', resetPlantVisualDetailed);

    $('#sim-crop')?.addEventListener('change', () => {
        resetPlantVisualDetailed();
        simLog('Crop profile changed. Resetting simulation.', 'info');
    });

    // Initialize the simulator view when the DOM is ready
    resetPlantVisualDetailed();
    simLog('Simulator ready.', 'info');
});

// Final initialization check for all sections
document.addEventListener('DOMContentLoaded', () => {
    // Initial setup for KCC section
    if (kccHasNo) kccHasNo.checked = true;
    if (document.querySelector('.tab-content.active')?.id === 'tab-kcc') {
        toggleKccSections();
    }
});

const form = document.getElementById('plannerForm');
const resetBtn = document.getElementById('resetForm');
const downloadBtn = document.getElementById('downloadReport');

const monthlyBridgeEl = document.getElementById('monthlyBridge');
const annualNetEl = document.getElementById('annualNet');
const annualGrossEl = document.getElementById('annualGross');
const annualYieldEl = document.getElementById('annualYield');
const yieldMultiplierEl = document.getElementById('yieldMultiplier');
const readinessList = document.getElementById('readinessList');

const monthlyCanvas = document.getElementById('monthlyChart');
const yearlyCanvas = document.getElementById('yearlyChart');
const canvases = [monthlyCanvas, yearlyCanvas];

const AGE_FACTORS = [
  { min: 0, max: 2, multiplier: 0 },
  { min: 3, max: 3, multiplier: 0.4 },
  { min: 4, max: 4, multiplier: 0.7 },
  { min: 5, max: Infinity, multiplier: 1 }
];

const syncCanvasDimensions = () => {
  const dpr = window.devicePixelRatio || 1;
  canvases.forEach(canvas => {
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  });
};

let latestPayload = {};
let lastResults = null;
let lastResultsSource = 'server';

const currency = value =>
  `₹${value.toLocaleString('en-IN', {
    maximumFractionDigits: 0
  })}`;

const debounce = (fn, delay = 250) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
};

const gatherInputs = () => {
  const data = new FormData(form);
  return Array.from(data.entries()).reduce((acc, [key, val]) => {
    acc[key] = Number(val);
    return acc;
  }, {});
};

const resolveAgeMultiplier = ageYears => {
  for (const band of AGE_FACTORS) {
    if (ageYears >= band.min && ageYears <= band.max) {
      return band.multiplier;
    }
  }
  return 1;
};

const computeProjectionLocal = (inputs, baseYield) =>
  Array.from({ length: 6 }, (_, idx) => {
    const year = idx + 1;
    const factor = resolveAgeMultiplier(year);
    const yearlyYield = baseYield * factor;
    const gross = yearlyYield * inputs.ffbPrice;
    const net = gross - inputs.farmArea * inputs.costPerAcre;
    return {
      year,
      netIncome: Math.max(net, 0)
    };
  });

const computeMetricsLocal = payload => {
  const sanitize = value => {
    const parsed = parseFloat(value);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
  };

  const inputs = {
    palms: sanitize(payload.palms),
    ageYears: sanitize(payload.ageYears),
    farmArea: sanitize(payload.farmArea),
    bunchesPerPalm: sanitize(payload.bunchesPerPalm),
    bunchWeight: sanitize(payload.bunchWeight),
    ffbPrice: sanitize(payload.ffbPrice),
    costPerAcre: sanitize(payload.costPerAcre)
  };

  const baseYieldTons = (inputs.palms * inputs.bunchesPerPalm * inputs.bunchWeight) / 1000;
  const multiplier = resolveAgeMultiplier(inputs.ageYears);
  const annualFFBYield = baseYieldTons * multiplier;
  const annualGrossIncome = annualFFBYield * inputs.ffbPrice;
  const annualCost = inputs.farmArea * inputs.costPerAcre;
  const annualNetIncome = annualGrossIncome - annualCost;
  const monthlyBridge = annualNetIncome / 12;

  return {
    inputs,
    annualFFBYield,
    annualGrossIncome,
    annualNetIncome,
    monthlyBridge,
    annualCost,
    baseYieldTons,
    multiplier,
    projections: computeProjectionLocal(inputs, baseYieldTons)
  };
};

const animateValue = (node, start, end, suffix = '', duration = 600) => {
  const startTime = performance.now();
  const step = now => {
    const progress = Math.min((now - startTime) / duration, 1);
    const value = start + (end - start) * progress;
    node.textContent = `${currency(Math.max(value, 0))}${suffix}`;
    if (progress < 1) {
      requestAnimationFrame(step);
    }
  };
  requestAnimationFrame(step);
};

const animatePlainValue = (node, start, end, unit = '', duration = 600) => {
  const startTime = performance.now();
  const step = now => {
    const progress = Math.min((now - startTime) / duration, 1);
    const value = start + (end - start) * progress;
    node.textContent = `${value.toFixed(2)} ${unit}`.trim();
    if (progress < 1) {
      requestAnimationFrame(step);
    }
  };
  requestAnimationFrame(step);
};

const drawRoundedRect = (ctx, x, y, width, height, radius = 8) => {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
};

const drawChart = (canvas, dataset, options = {}) => {
  const ctx = canvas.getContext('2d');
  const { labels, values } = dataset;
  const {
    color = '#10b981',
    gradient = ['rgba(16,185,129,0.4)', 'rgba(16,185,129,0.05)'],
    type = 'bar'
  } = options;

  const padding = 40;
  const dpr = window.devicePixelRatio || 1;
  const width = canvas.width / dpr;
  const height = canvas.height / dpr;
  const chartHeight = height - padding * 2;
  const chartWidth = width - padding * 2;
  const barWidth = chartWidth / values.length - 12;
  const maxValue = Math.max(...values, 1);

  let progress = 0;
  if (canvas._frameId) {
    cancelAnimationFrame(canvas._frameId);
  }

  const render = () => {
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(padding, padding);

    ctx.strokeStyle = 'rgba(15,23,42,0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, chartHeight);
    ctx.lineTo(chartWidth, chartHeight);
    ctx.stroke();

    values.forEach((value, index) => {
      const x = index * (barWidth + 12);
      const scaled = (value / maxValue) * chartHeight * progress;
      const y = chartHeight - scaled;

      if (type === 'bar') {
        const grd = ctx.createLinearGradient(0, y, 0, chartHeight);
        grd.addColorStop(0, gradient[0]);
        grd.addColorStop(1, gradient[1]);
        ctx.fillStyle = grd;
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        drawRoundedRect(ctx, x, y, barWidth, scaled, 10);
        ctx.fill();
        ctx.stroke();
      } else {
        ctx.lineWidth = 4;
        ctx.strokeStyle = color;
        if (index > 0) {
          const prevX = (index - 1) * (barWidth + 12);
          const prevY = chartHeight - ((values[index - 1] / maxValue) * chartHeight * progress);
          ctx.beginPath();
          ctx.moveTo(prevX, prevY);
          ctx.lineTo(x, y);
          ctx.stroke();
        }
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.fillStyle = '#0f172a';
      ctx.font = '12px Manrope';
      ctx.textAlign = 'center';
      ctx.fillText(labels[index], x + barWidth / 2, chartHeight + 18);
    });

    ctx.restore();
    if (progress < 1) {
      progress += 0.03;
      canvas._frameId = requestAnimationFrame(render);
    }
  };

  render();
};

const createMonthlySeries = monthlyBridge => {
  const base = Math.max(monthlyBridge, 0);
  return Array.from({ length: 12 }, (_, idx) => {
    const seasonal = Math.sin((idx / 12) * Math.PI * 2) * 0.08;
    return base * (1 + seasonal);
  });
};

const updateChecklist = data => {
  const points = [
    {
      title: data.annualNetIncome >= 0 ? 'Cash-positive outlook' : 'Address negative cashflow',
      description:
        data.annualNetIncome >= 0
          ? 'Net income stays positive after deducting cultivation costs.'
          : 'Increase yield or optimise costs to edge into surplus.',
      icon: data.annualNetIncome >= 0 ? '✓' : '!'
    },
    {
      title: 'Yield multiplier applied',
      description: `Age factor now at ${(data.multiplier * 100).toFixed(0)}% for palms aged ${data.inputs.ageYears} years.`,
      icon: '⟳'
    },
    {
      title: 'Bridge runway',
      description: `Monthly bridge set at ${currency(data.monthlyBridge)} for 12 months.`,
      icon: '∞'
    }
  ];

  readinessList.innerHTML = '';
  points.forEach(point => {
    const block = document.createElement('div');
    block.className = 'checklist-item';
    block.innerHTML = `
      <div class="check-icon">${point.icon}</div>
      <div>
        <h5>${point.title}</h5>
        <p>${point.description}</p>
      </div>
    `;
    readinessList.appendChild(block);
  });
};

const updateUI = data => {
  if (!lastResults) {
    monthlyBridgeEl.textContent = currency(data.monthlyBridge);
    annualNetEl.textContent = currency(data.annualNetIncome);
    annualGrossEl.textContent = currency(data.annualGrossIncome);
    annualYieldEl.textContent = `${data.annualFFBYield.toFixed(2)} tons`;
  } else {
    animateValue(monthlyBridgeEl, lastResults.monthlyBridge, data.monthlyBridge);
    animateValue(annualNetEl, lastResults.annualNetIncome, data.annualNetIncome);
    animateValue(annualGrossEl, lastResults.annualGrossIncome, data.annualGrossIncome);
    animatePlainValue(annualYieldEl, lastResults.annualFFBYield, data.annualFFBYield, 'tons');
  }

  yieldMultiplierEl.textContent = `Multiplier ${(data.multiplier * 100).toFixed(0)}%`;

  const monthlySeries = createMonthlySeries(data.monthlyBridge);
  drawChart(
    monthlyCanvas,
    {
      labels: ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'],
      values: monthlySeries
    },
    { type: 'bar' }
  );

  drawChart(
    yearlyCanvas,
    {
      labels: data.projections.map(item => `Y${item.year}`),
      values: data.projections.map(item => item.netIncome)
    },
    { type: 'line', color: '#0d9488' }
  );

  updateChecklist(data);
  lastResults = data;
};

const runCalculation = async () => {
  const payload = gatherInputs();
  latestPayload = payload;
  try {
    const res = await fetch('/api/calculate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      throw new Error(`Server responded with ${res.status}`);
    }
    const data = await res.json();
    lastResultsSource = 'server';
    updateUI(data);
  } catch (err) {
    console.warn('Falling back to local calculations', err);
    const data = computeMetricsLocal(payload);
    lastResultsSource = 'local';
    updateUI(data);
  }
};

const renderLocalReport = data => {
  const reportWindow = window.open('', '_blank', 'width=900,height=700');
  if (!reportWindow) {
    alert('Please allow popups to preview the report.');
    return;
  }

  const currencyString = amount =>
    `₹${amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <title>Green Income Bridge Report</title>
        <style>
          body { font-family: 'Manrope', Arial, sans-serif; padding: 32px; color: #0f172a; }
          h1 { color: #047857; }
          section { margin-bottom: 24px; }
          .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; }
          .card { border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px 16px; background: #f8fbf9; }
          .muted { color: #475569; font-size: 0.95rem; }
        </style>
      </head>
      <body>
        <h1>Green Income Bridge Planner</h1>
        <p class="muted">Offline snapshot generated on ${new Date().toLocaleString()}</p>
        <section>
          <h2>Farm Inputs</h2>
          <div class="grid">
            ${Object.entries(data.inputs)
              .map(([key, value]) => `<div class="card"><strong>${key}</strong><div>${value}</div></div>`)
              .join('')}
          </div>
        </section>
        <section>
          <h2>Financial Summary</h2>
          <div class="grid">
            <div class="card"><strong>Annual FFB Yield</strong><div>${data.annualFFBYield.toFixed(2)} tons</div></div>
            <div class="card"><strong>Annual Gross Income</strong><div>${currencyString(
              data.annualGrossIncome
            )}</div></div>
            <div class="card"><strong>Annual Net Income</strong><div>${currencyString(
              data.annualNetIncome
            )}</div></div>
            <div class="card"><strong>Monthly Bridge</strong><div>${currencyString(
              data.monthlyBridge
            )}</div></div>
          </div>
        </section>
        <section>
          <h2>Projected Net Incomes</h2>
          <ul>
            ${data.projections
              .map(
                projection =>
                  `<li>Year ${projection.year}: ${currencyString(projection.netIncome)}</li>`
              )
              .join('')}
          </ul>
        </section>
        <script>
          setTimeout(() => window.print(), 400);
        </script>
      </body>
    </html>
  `;

  reportWindow.document.write(html);
  reportWindow.document.close();
};

const downloadReport = async () => {
  try {
    const res = await fetch('/api/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(latestPayload)
    });
    if (!res.ok) throw new Error('Failed to generate report');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'green-income-bridge.pdf';
    link.click();
    URL.revokeObjectURL(url);
  } catch (error) {
    console.warn('Falling back to local report preview', error);
    const fallbackData = lastResults || computeMetricsLocal(latestPayload);
    renderLocalReport(fallbackData);
  }
};

const resetPlanner = () => {
  form.reset();
  runCalculation();
};

const debouncedRun = debounce(runCalculation, 200);
const handleResize = debounce(() => {
  syncCanvasDimensions();
  if (lastResults) {
    updateUI(lastResults);
  }
}, 200);

form.addEventListener('input', debouncedRun);
resetBtn.addEventListener('click', () => {
  resetPlanner();
});
downloadBtn.addEventListener('click', downloadReport);
window.addEventListener('resize', handleResize);

// WHEN GIB TAB OPENS → FIX CANVAS SIZE + REDRAW CHARTS
document.querySelector('[data-tab-id="gib"]').addEventListener('click', () => {
    setTimeout(() => {
        syncCanvasDimensions();  // Fix size
        if (lastResults) updateUI(lastResults);  // Redraw charts
    }, 50);
});

syncCanvasDimensions();
runCalculation();

// chatbot.js - FINAL VERSION with Text/Voice Input, Integrated Voice Translation, and Copy/Share Buttons

// --- DOM Element References ---
const chatbotIcon = document.getElementById('chatbot-icon');
const chatbotPopup = document.getElementById('chatbot-popup');
const chatbotCloseBtn = document.getElementById('chatbot-close-btn');
const messagesContainer = document.getElementById('chatbot-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const micBtn = document.getElementById('mic-btn'); 
// Ensure your HTML contains a placeholder for this notification if you want to see the confirmation message
let notificationContainer = document.getElementById('notification-container');


// --- VOICE API SETUP ---
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const synth = window.speechSynthesis; 

let recognition;

if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false; 
    recognition.lang = 'en-IN'; 
    
    // --- Recognition Event Handlers ---
    recognition.onstart = () => {
        micBtn.classList.add('mic-listening');
        micBtn.innerHTML = 'stop';
        userInput.placeholder = "Listening... Speak now.";
    };

    recognition.onend = () => {
        micBtn.classList.remove('mic-listening');
        micBtn.innerHTML = 'mic';
        userInput.placeholder = "Type or tap the mic to speak...";
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        userInput.value = transcript;
        sendMessage(); 
    };

    recognition.onerror = (event) => {
        console.error('Speech Recognition Error:', event.error);
    };
} else {
    if (micBtn) micBtn.style.display = 'none';
    console.warn('Web Speech API not supported in this browser.');
}


// --- COPY & SHARE UTILITY FUNCTIONS ---

/**
 * Shows a temporary notification message (since alert() is forbidden).
 */
function showTemporaryMessage(message, type = 'info') {
    if (!notificationContainer) {
        // Create notification container if it doesn't exist (basic styling)
        notificationContainer = document.createElement('div');
        notificationContainer.id = 'notification-container';
        Object.assign(notificationContainer.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            backgroundColor: '#4CAF50',
            color: 'white',
            padding: '10px 20px',
            borderRadius: '5px',
            zIndex: '1000',
            display: 'none',
            fontSize: '14px',
            boxShadow: '0 2px 10px rgba(0,0,0,0.2)'
        });
        document.body.appendChild(notificationContainer);
    }
    
    // Set type-specific styling
    if (type === 'error') notificationContainer.style.backgroundColor = '#f44336';
    if (type === 'warning') notificationContainer.style.backgroundColor = '#ff9800';
    if (type === 'success') notificationContainer.style.backgroundColor = '#4CAF50';
    if (type === 'info') notificationContainer.style.backgroundColor = '#2196F3';


    notificationContainer.textContent = message;
    notificationContainer.style.display = 'block';

    setTimeout(() => {
        notificationContainer.style.display = 'none';
    }, 3000);
}

/**
 * Copies the provided text to the clipboard.
 */
function copyToClipboard(text) {
    // 1. Clean text: Replace HTML breaks with newlines
    const cleanText = text.replace(/<br>/g, '\n');

    // 2. Use document.execCommand('copy') for better iframe compatibility
    const textarea = document.createElement('textarea');
    textarea.value = cleanText;
    // Set off-screen to prevent visual disruption
    Object.assign(textarea.style, {
        position: 'absolute',
        left: '-9999px'
    });
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
        document.execCommand('copy');
        showTemporaryMessage('Text copied to clipboard!', 'success');
    } catch (err) {
        console.error('Copy failed:', err);
        showTemporaryMessage('Copy failed. Manual copy required.', 'error');
    }
    document.body.removeChild(textarea);
}

/**
 * Shares the content using the Web Share API or falls back to copying.
 */
function shareContent(text) {
    const cleanText = text.replace(/<br>/g, '\n');
    if (navigator.share) {
        navigator.share({
            title: 'Seed Intel Assistant Response',
            text: cleanText,
        }).then(() => {
            showTemporaryMessage('Content shared successfully!', 'success');
        }).catch(error => {
            if (error.name !== 'AbortError') {
                console.warn('Sharing failed:', error);
                showTemporaryMessage('Sharing failed. Text copied to clipboard instead.', 'warning');
                copyToClipboard(cleanText); // Fallback to copy if share fails
            }
        });
    } else {
        // Fallback for browsers without Web Share API
        copyToClipboard(cleanText);
        showTemporaryMessage('Share API not supported. Text copied to clipboard instead.', 'info');
    }
}


// --- VOICE OUTPUT FUNCTIONS (Unchanged) ---
function speakEnglishResponse(text) {
    if (!synth) return; 
    const cleanText = text.replace(/<br>/g, '. ');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'en-US'; 
    synth.speak(utterance);
}

function speakTranslatedResponse(text, langCode) {
    if (!synth || !text || !langCode) return; 
    synth.cancel(); 

    const cleanText = text.replace(/<br>/g, '. ');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    
    utterance.lang = langCode; 
    
    const voices = synth.getVoices();
    const specificVoice = voices.find(voice => voice.lang.startsWith(langCode.substring(0, 2)));
    if (specificVoice) {
        utterance.voice = specificVoice;
    }
    
    synth.speak(utterance);
}


// --- EVENT LISTENERS (Unchanged) ---
chatbotIcon.addEventListener('click', () => {
    chatbotPopup.classList.toggle('hidden');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
});

chatbotCloseBtn.addEventListener('click', () => {
    chatbotPopup.classList.add('hidden');
    if (recognition && micBtn.classList.contains('mic-listening')) recognition.stop();
    if (synth.speaking) synth.cancel();
});

sendBtn.addEventListener('click', sendMessage);

if (micBtn) {
    micBtn.addEventListener('click', () => {
        if (micBtn.classList.contains('mic-listening')) {
            recognition.stop(); 
        } else {
            try {
                if (synth.speaking) synth.cancel();
                recognition.start(); 
            } catch (e) {
                console.warn("Recognition start error:", e);
            }
        }
    });
}


// --- HELPER FUNCTIONS ---
function appendMessage(text, sender, isTranslation = false) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(isTranslation ? 'translation-message' : `${sender}-message`);
    
    const contentText = isTranslation ? `<strong>Translation:</strong> ${text}` : text;
    
    // Create the content element
    const contentDiv = document.createElement('div');
    contentDiv.innerHTML = contentText;
    contentDiv.classList.add('message-content-text'); 

    messageDiv.appendChild(contentDiv);
    
    // --- ADD COPY AND SHARE BUTTONS ---
    if (sender === 'assistant' || isTranslation) {
        const actionsDiv = document.createElement('div');
        actionsDiv.classList.add('message-actions');
        
        // Use the original text for copying, not the wrapped HTML
        const rawText = text.replace(/<strong>Translation:<\/strong>\s*/, '');
        
        // SVG for Copy Icon
        const copySvg = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clipboard"><rect width="8" height="4" x="8" y="2"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/></svg>`;
        
        // SVG for Share Icon
        const shareSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-share-2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg>`;

        // Copy Button (Professional style)
        const copyBtn = document.createElement('button');
        copyBtn.innerHTML = `${copySvg} Copy Text`; 
        copyBtn.title = 'Copy Text';
        copyBtn.classList.add('action-icon');
        copyBtn.onclick = () => copyToClipboard(rawText);
        
        // Share Button (Professional style)
        const shareBtn = document.createElement('button');
        shareBtn.innerHTML = `${shareSvg} Share Content`; 
        shareBtn.title = 'Share Content';
        shareBtn.classList.add('action-icon');
        shareBtn.onclick = () => shareContent(rawText);

        actionsDiv.appendChild(copyBtn);
        actionsDiv.appendChild(shareBtn);
        messageDiv.appendChild(actionsDiv);
        
        // --- Apply Professional Block Styling ---
        
        // Container for action buttons (placed below the text)
        Object.assign(actionsDiv.style, {
            marginTop: '10px',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            maxWidth: '200px', // Restrict width to look like the screenshot
        });

        // Styling for individual buttons
        const buttons = messageDiv.querySelectorAll('.action-icon');
        buttons.forEach(btn => {
            Object.assign(btn.style, {
                backgroundColor: '#ffffff', 
                color: '#333333', 
                border: '1px solid #e0e0e0',
                borderRadius: '8px',
                padding: '10px 15px',
                cursor: 'pointer',
                fontWeight: '500',
                fontSize: '14px',
                textAlign: 'left',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
                transition: 'background-color 0.2s, box-shadow 0.2s',
            });
            
            // Add mouse event listeners for hover effects (since inline CSS doesn't support :hover)
            btn.onmouseover = () => {
                btn.style.backgroundColor = '#f0f0f0';
                btn.style.boxShadow = '0 2px 6px rgba(0, 0, 0, 0.1)';
            };
            btn.onmouseout = () => {
                btn.style.backgroundColor = '#ffffff';
                btn.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.05)';
            };
        });
    }

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

async function sendMessage() {
    const message = userInput.value.trim();
    if (message === '') return; 

    // 1. Setup UI for pending response
    if (recognition && micBtn && micBtn.classList.contains('mic-listening')) recognition.stop();
    if (synth.speaking) synth.cancel();

    appendMessage(message, 'user');
    userInput.value = '';
    userInput.disabled = true;
    sendBtn.disabled = true;
    if (micBtn) micBtn.disabled = true; 

    const typingIndicator = document.createElement('div');
    typingIndicator.classList.add('message', 'assistant-message', 'typing-indicator');
    typingIndicator.innerHTML = 'Assistant is typing...';
    messagesContainer.appendChild(typingIndicator);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    try {
        const response = await fetch('http://127.0.0.1:3000/api/chat', { 
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        
        const englishResponse = data.englishResponse; 
        const translatedText = data.translatedText;
        const langCode = data.translatedLangCode;

        // 2. Display the English response
        typingIndicator.remove();
        appendMessage(englishResponse, 'assistant'); 
        
        // 3. Handle Translation
        if (translatedText && langCode) {
            // Display the translated text
            appendMessage(translatedText, 'assistant', true); 
            
            // Speak the translated text in the correct language accent
            speakTranslatedResponse(translatedText, langCode);
        } else {
            // Speak the default English response
            speakEnglishResponse(englishResponse);
        }

    } catch (error) {
        console.error('Connection Error:', error);
        typingIndicator.remove();
        appendMessage('Connection failed. Please ensure the Node.js server is running and your API key is valid.', 'assistant');
    } finally {
        // 4. Re-enable UI
        userInput.disabled = false;
        sendBtn.disabled = false;
        if (micBtn) micBtn.disabled = false; 
        userInput.focus();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    appendMessage('Hello! I am the Seed Intel Assistant. Ask me anything about farming in India, and include "translate to Hindi" if you need it in a regional language!', 'assistant');
});

// FFB Price Calculator - JavaScript Logic

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  
  // Get DOM elements
  const calculateBtn = document.getElementById('calculateBtn');
  const resetBtn = document.getElementById('resetBtn');
  const results = document.getElementById('results');
  const canvas = document.getElementById('priceChart');
  const ctx = canvas.getContext('2d');
  const pieCanvas = document.getElementById('sharePieChart');
  const pieCtx = pieCanvas.getContext('2d');
  // device pixel ratio for crisp canvases
  const DPR = window.devicePixelRatio || 1;

  // Resize canvases to account for DPR (call before drawing)
  function resizeCanvases() {
    // price chart
    const cssWidth = canvas.clientWidth || 800;
    const cssHeight = canvas.clientHeight || 300;
    canvas.width = Math.round(cssWidth * DPR);
    canvas.height = Math.round(cssHeight * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);

    // pie chart
    const pCssWidth = pieCanvas.clientWidth || 300;
    const pCssHeight = pieCanvas.clientHeight || 300;
    pieCanvas.width = Math.round(pCssWidth * DPR);
    pieCanvas.height = Math.round(pCssHeight * DPR);
    pieCtx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }

  // initial resize and on window resize
  resizeCanvases();
  window.addEventListener('resize', () => {
    resizeCanvases();
  });

  // Result display elements
  const farmerPriceEl = document.getElementById('farmerPrice');
  const oilContributionEl = document.getElementById('oilContribution');
  const kernelContributionEl = document.getElementById('kernelContribution');
  const advisoryListEl = document.getElementById('advisoryList');

  // Input elements
  const cpoInput = document.getElementById('cpo');
  const oerInput = document.getElementById('oer');
  const shareInput = document.getElementById('share');
  const stateSelect = document.getElementById('state');
  const pkoInput = document.getElementById('pko');
  const kerInput = document.getElementById('ker');
  const unitInput = document.getElementById('unit');

  // Calculate FFB price using the exact formula
  function calculateFFBPrice(cpo, oer, share, pko, ker, unit) {
    // Convert percentages to decimals
    const oerDecimal = oer / 100;
    const kerDecimal = ker / 100;
    const shareDecimal = share / 100;

    // Calculate price per kg using exact formula
    // Formula: (CPO × OER × Share) + (PKO × KER × Share)
    const oilValuePerKg = cpo * oerDecimal * shareDecimal;
    const kernelValuePerKg = pko * kerDecimal * shareDecimal;
    const pricePerKg = oilValuePerKg + kernelValuePerKg;

    // Calculate for selected unit (kg or ton)
    const totalPrice = pricePerKg * unit;
    const oilContribution = oilValuePerKg * unit;
    const kernelContribution = kernelValuePerKg * unit;

    return {
      totalPrice: totalPrice,
      oilContribution: oilContribution,
      kernelContribution: kernelContribution,
      pricePerKg: pricePerKg
    };
  }

  // Generate advisory messages based on input values
  function generateAdvisory(oer, share, ker, kernelContribution, unit) {
    // Return advisory objects with severity and recommended actions
    const advisories = [];

    const push = (severity, title, details, action) => {
      advisories.push({ severity, title, details, action });
    };

    // Heuristic checks
    if (oer < 16) {
      push('high', 'Low OER', 'OER is below 16%. Improve irrigation schedule, soil testing and apply balanced NPK fertilizers. Inspect for pest/disease.', 'Check soil & fertilizer program');
    } else if (oer < 17.5) {
      push('medium', 'Below-average OER', 'OER is slightly below target. Review harvesting maturity and nutrient inputs.', 'Review harvest timing');
    } else {
      push('low', 'Healthy OER', 'OER is good. Maintain current crop management practices.', 'Keep records of best practices');
    }

    if (share < 70) {
      push('high', 'Low Farmer Share', 'Farmer share is under 70%. Verify mill pricing and applicable state policies. Negotiate or seek cooperative pricing.', 'Contact mill or extension officer');
    } else if (share < 75) {
      push('medium', 'Average Farmer Share', 'Share is moderate. Compare with nearby mills and check for deductions.', 'Compare mill offers');
    } else {
      push('low', 'Good Farmer Share', 'Share percentage looks favorable.', 'Continue monitoring market');
    }

    if (ker < 3.5) {
      push('medium', 'Low KER', 'Kernel extraction rate below typical range. Ensure fruits are mature and processed correctly.', 'Check fruit maturity and processing');
    } else {
      push('low', 'Healthy KER', 'KER is within or above expected range.', 'Keep records');
    }

    const kernelThreshold = unit === 1000 ? 500 : 0.5;
    if (kernelContribution < kernelThreshold) {
      push('medium', 'Low Kernel Value', 'Kernel contribution to income is low; focus on harvesting mature bunches and minimizing kernel losses during processing.', 'Improve harvesting & handling');
    }

    if (oer >= 18 && ker >= 3.8) {
      push('low', 'Excellent Extraction Rates', 'You have excellent OER and KER — current management practices are effective.', 'Document methods for reference');
    }

    // Sort advisories by severity (high -> medium -> low)
    const severityOrder = { high: 0, medium: 1, low: 2 };
    advisories.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);

    return advisories;
  }

  // Draw animated bar chart
  function drawChart(oilValue, kernelValue, total, unit) {
    // Clear canvas (use CSS px coords because ctx is scaled)
    ctx.clearRect(0, 0, canvas.width / DPR, canvas.height / DPR);

    // Set dimensions (CSS pixels)
    const padding = 40;
    const chartWidth = canvas.width / DPR - padding * 2;
    const chartHeight = canvas.height / DPR - padding * 2;
    const barHeight = 64;
    const spacing = 40;

    // Calculate bar widths (proportional to values)
    const maxValue = total;
    const targetOilWidth = maxValue > 0 ? (oilValue / maxValue) * chartWidth : 0;
    const targetKernelWidth = maxValue > 0 ? (kernelValue / maxValue) * chartWidth : 0;

    // Animation state
    const steps = 60;
    let step = 0;

    const oilY = 70;
    const kernelY = oilY + barHeight + spacing;

    // Animated draw loop
    function animate() {
      step++;
      const t = Math.min(1, step / steps);
      const ease = 1 - Math.pow(1 - t, 3);

      const oilCurrent = targetOilWidth * ease;
      const kernelCurrent = targetKernelWidth * ease;

      // clear drawing area
      ctx.clearRect(0, 0, canvas.width / DPR, canvas.height / DPR);

      // Title
      ctx.fillStyle = '#1a3d0f';
      ctx.font = 'bold 18px Segoe UI';
      ctx.fillText('Price Breakdown - Visual Contribution', padding, 30);

      // Gridlines
      ctx.strokeStyle = 'rgba(26,61,15,0.06)';
      ctx.lineWidth = 1;
      const ticks = 4;
      ctx.font = '12px Segoe UI';
      ctx.fillStyle = 'rgba(26,61,15,0.8)';
      for (let i = 0; i <= ticks; i++) {
        const y = padding + (chartHeight / ticks) * i;
        const value = maxValue - (maxValue / ticks) * i;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(padding + chartWidth, y);
        ctx.stroke();
        ctx.fillText(`₹${value.toFixed(2)}`, 6, y + 4);
      }

      // Background bars
      ctx.fillStyle = '#e8f5e0';
      roundRect(ctx, padding, oilY, chartWidth, barHeight, 10);
      ctx.fill();
      ctx.fillStyle = '#fef3c7';
      roundRect(ctx, padding, kernelY, chartWidth, barHeight, 10);
      ctx.fill();

      // Oil foreground glossy gradient
      const oilGradient = ctx.createLinearGradient(padding, oilY, padding + oilCurrent, oilY);
      oilGradient.addColorStop(0, '#9bd36a');
      oilGradient.addColorStop(0.6, '#73a942');
      oilGradient.addColorStop(1, '#5a8535');
      ctx.fillStyle = oilGradient;
      roundRect(ctx, padding, oilY, oilCurrent, barHeight, 10);
      ctx.fill();

      // Add gloss overlay
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      roundRect(ctx, padding + 2, oilY + 2, oilCurrent - 4, barHeight / 2 - 6, 10);
      ctx.fill();

      // Kernel foreground glossy gradient
      const kGrad = ctx.createLinearGradient(padding, kernelY, padding + kernelCurrent, kernelY);
      kGrad.addColorStop(0, '#ffd28a');
      kGrad.addColorStop(0.6, '#f59e0b');
      kGrad.addColorStop(1, '#d97706');
      ctx.fillStyle = kGrad;
      roundRect(ctx, padding, kernelY, kernelCurrent, barHeight, 10);
      ctx.fill();

      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      roundRect(ctx, padding + 2, kernelY + 2, kernelCurrent - 4, barHeight / 2 - 6, 10);
      ctx.fill();

      // Labels
      ctx.fillStyle = '#1a3d0f';
      ctx.font = 'bold 14px Segoe UI';
      ctx.fillText('Oil Contribution', padding, oilY - 8);
      ctx.fillText('Kernel Contribution', padding, kernelY - 8);

      // Marker dots with subtle shadow
      drawMarker(padding + Math.max(8, oilCurrent), oilY + barHeight / 2, '#ffffff', '#2f6b2d');
      drawMarker(padding + Math.max(8, kernelCurrent), kernelY + barHeight / 2, '#ffffff', '#8b4f06');

      // Value texts
      ctx.font = 'bold 16px Segoe UI';
      ctx.fillStyle = oilCurrent > 100 ? 'white' : '#1a3d0f';
      ctx.fillText(`₹${oilValue.toFixed(2)}`, padding + Math.min(chartWidth - 20, oilCurrent) - 8, oilY + 38);
      ctx.fillStyle = kernelCurrent > 100 ? 'white' : '#1a3d0f';
      ctx.fillText(`₹${kernelValue.toFixed(2)}`, padding + Math.min(chartWidth - 20, kernelCurrent) - 8, kernelY + 38);

      // legend
      ctx.fillStyle = '#5a7049';
      ctx.font = '14px Segoe UI';
      const unitText = unit === 1000 ? 'per ton' : 'per kg';
      ctx.fillText(`Total FFB Price: ₹${total.toFixed(2)} ${unitText}`, padding, kernelY + barHeight + 40);

      if (step < steps) requestAnimationFrame(animate);
    }

    // small helper: rounded rect path
    function roundRect(ctx, x, y, w, h, r) {
      if (w <= 0) return;
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r);
      ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r);
      ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    }

    function drawMarker(x, y, fill, stroke) {
      ctx.save();
      ctx.beginPath();
      ctx.shadowColor = 'rgba(0,0,0,0.15)';
      ctx.shadowBlur = 8;
      ctx.fillStyle = fill;
      ctx.arc(x, y, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = stroke;
      ctx.stroke();
      ctx.restore();
    }

    requestAnimationFrame(animate);
  }

  // Draw animated pie chart showing oil vs kernel contribution (within farmer share)
  function drawPieChart(oilValue, kernelValue) {
    const total = oilValue + kernelValue;
    pieCtx.clearRect(0, 0, pieCanvas.width / DPR, pieCanvas.height / DPR);

    const cx = (pieCanvas.width / DPR) / 2;
    const cy = (pieCanvas.height / DPR) / 2;
    const radius = Math.min(cx, cy) - 20;

    const oilAngle = total > 0 ? (oilValue / total) * Math.PI * 2 : 0;
    const kernelAngle = total > 0 ? (kernelValue / total) * Math.PI * 2 : 0;

    let currentAngle = -Math.PI / 2; // start at top
    const steps = 60;
    let step = 0;
    let shownOilPercent = 0;
    let shownKernelPercent = 0;

    function animate() {
      step++;
      const t = Math.min(1, step / steps);
      const prog = 1 - Math.pow(1 - t, 3);

      pieCtx.clearRect(0, 0, pieCanvas.width / DPR, pieCanvas.height / DPR);

      // radial gloss background
      const grad = pieCtx.createRadialGradient(cx, cy - 10, radius * 0.2, cx, cy, radius * 1.2);
      grad.addColorStop(0, 'rgba(255,255,255,0.55)');
      grad.addColorStop(0.4, 'rgba(255,255,255,0.08)');
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      pieCtx.fillStyle = grad;
      pieCtx.beginPath();
      pieCtx.arc(cx, cy, radius + 12, 0, Math.PI * 2);
      pieCtx.fill();

      // draw oil slice with soft border
      pieCtx.beginPath();
      pieCtx.moveTo(cx, cy);
      pieCtx.fillStyle = '#73a942';
      pieCtx.arc(cx, cy, radius, currentAngle, currentAngle + oilAngle * prog);
      pieCtx.closePath();
      pieCtx.fill();
      pieCtx.strokeStyle = 'rgba(0,0,0,0.06)';
      pieCtx.lineWidth = 1;
      pieCtx.stroke();

      // draw kernel slice
      pieCtx.beginPath();
      pieCtx.moveTo(cx, cy);
      pieCtx.fillStyle = '#f59e0b';
      pieCtx.arc(cx, cy, radius, currentAngle + oilAngle * prog, currentAngle + (oilAngle + kernelAngle) * prog);
      pieCtx.closePath();
      pieCtx.fill();
      pieCtx.stroke();

      // gloss highlight on top of pie
      pieCtx.beginPath();
      pieCtx.fillStyle = 'rgba(255,255,255,0.14)';
      pieCtx.ellipse(cx, cy - radius * 0.25, radius * 0.9, radius * 0.55, 0, Math.PI * 1.05, Math.PI * 1.95);
      pieCtx.fill();

      // callout labels
      const oilMid = currentAngle + (oilAngle * prog) / 2;
      const kernelMid = currentAngle + (oilAngle * prog) + (kernelAngle * prog) / 2;

      function drawLabel(angle, text, color) {
        const lx = cx + Math.cos(angle) * (radius + 22);
        const ly = cy + Math.sin(angle) * (radius + 22);
        pieCtx.beginPath();
        pieCtx.moveTo(cx + Math.cos(angle) * radius * 0.92, cy + Math.sin(angle) * radius * 0.92);
        pieCtx.lineTo(lx, ly);
        pieCtx.strokeStyle = 'rgba(0,0,0,0.12)';
        pieCtx.lineWidth = 1;
        pieCtx.stroke();

        pieCtx.fillStyle = 'rgba(255,255,255,0.95)';
        pieCtx.fillRect(lx - 40, ly - 14, 80, 24);
        pieCtx.fillStyle = color;
        pieCtx.font = '12px Segoe UI';
        pieCtx.textAlign = 'center';
        pieCtx.fillText(text, lx, ly + 4);
      }

      const oilPercent = total > 0 ? (oilValue / total) * 100 : 0;
      const kernelPercent = total > 0 ? (kernelValue / total) * 100 : 0;

      // animate numeric counters
      shownOilPercent = shownOilPercent + (oilPercent - shownOilPercent) * 0.12;
      shownKernelPercent = shownKernelPercent + (kernelPercent - shownKernelPercent) * 0.12;

      drawLabel(oilMid, `Oil ${shownOilPercent.toFixed(1)}%`, '#155724');
      drawLabel(kernelMid, `Kernel ${shownKernelPercent.toFixed(1)}%`, '#92400e');

      // center title and totals
      pieCtx.fillStyle = '#1a3d0f';
      pieCtx.font = 'bold 13px Segoe UI';
      pieCtx.textAlign = 'center';
      pieCtx.fillText('Farmer Share Breakdown', cx, cy - 6);
      pieCtx.font = '12px Segoe UI';
      pieCtx.fillText(`Oil: ₹${oilValue.toFixed(2)}  •  Kernel: ₹${kernelValue.toFixed(2)}`, cx, cy + 16);

      if (step < steps) requestAnimationFrame(animate);
    }

    requestAnimationFrame(animate);
  }

  // Validate form inputs
  function validateInputs() {
    const cpo = parseFloat(cpoInput.value);
    const oer = parseFloat(oerInput.value);
    const share = parseFloat(shareInput.value);
    const pko = parseFloat(pkoInput.value);
    const ker = parseFloat(kerInput.value);

    if (isNaN(cpo) || cpo < 0) {
      alert('Please enter a valid CPO price');
      cpoInput.focus();
      return false;
    }

    if (isNaN(oer) || oer < 0 || oer > 100) {
      alert('Please enter a valid OER between 0 and 100');
      oerInput.focus();
      return false;
    }

    if (isNaN(share) || share < 0 || share > 100) {
      alert('Please enter a valid Farmer Share between 0 and 100');
      shareInput.focus();
      return false;
    }

    if (isNaN(pko) || pko < 0) {
      alert('Please enter a valid PKO price');
      pkoInput.focus();
      return false;
    }

    if (isNaN(ker) || ker < 0 || ker > 100) {
      alert('Please enter a valid KER between 0 and 100');
      kerInput.focus();
      return false;
    }

    return true;
  }

  // Handle calculate button click
  calculateBtn.addEventListener('click', function() {
    console.log('Calculate button clicked');

    // Validate inputs
    if (!validateInputs()) {
      return;
    }

    // Get input values
    const cpo = parseFloat(cpoInput.value);
    const oer = parseFloat(oerInput.value);
    const share = parseFloat(shareInput.value);
    const pko = parseFloat(pkoInput.value);
    const ker = parseFloat(kerInput.value);
    const unit = parseInt(unitInput.value);

    console.log('Input values:', { cpo, oer, share, pko, ker, unit });

    // Calculate results
    const result = calculateFFBPrice(cpo, oer, share, pko, ker, unit);
    console.log('Results:', result);

    // Update display
    const unitText = unit === 1000 ? '/ton' : '/kg';
    farmerPriceEl.textContent = `₹${result.totalPrice.toFixed(2)}${unitText}`;
    oilContributionEl.textContent = `₹${result.oilContribution.toFixed(2)}`;
    kernelContributionEl.textContent = `₹${result.kernelContribution.toFixed(2)}`;

    // Draw chart with animation
    drawChart(result.oilContribution, result.kernelContribution, result.totalPrice, unit);
    // Draw pie chart for farmer share breakdown (oil vs kernel)
    drawPieChart(result.oilContribution, result.kernelContribution);
    // Generate and display advisory (structured items)
    const advisories = generateAdvisory(oer, share, ker, result.kernelContribution, unit);
    advisoryListEl.innerHTML = advisories.map((adv, idx) => {
      return `
        <li class="advisory-item severity-${adv.severity}" data-idx="${idx}">
          <div class="advisory-head">
            <strong>${adv.title}</strong>
            <span class="advisory-action" data-idx="${idx}">Details</span>
          </div>
          <div class="advisory-body" style="display:none">${adv.details}<br/><em>Recommended:</em> ${adv.action}</div>
        </li>`;
    }).join('');

    // Add click listeners (event delegation) to toggle details
    advisoryListEl.querySelectorAll('.advisory-action').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = btn.getAttribute('data-idx');
        const li = advisoryListEl.querySelector(`li[data-idx='${idx}']`);
        if (!li) return;
        const body = li.querySelector('.advisory-body');
        if (!body) return;
        const visible = body.style.display !== 'none';
        body.style.display = visible ? 'none' : 'block';
        btn.textContent = visible ? 'Details' : 'Hide';
      });
    });

    // Show results with animation
    results.classList.add('show');
    
    // Smooth scroll to results
    setTimeout(() => {
      results.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 100);
  });

  // Handle reset button click
  resetBtn.addEventListener('click', function() {
    console.log('Reset button clicked');
    
    // Clear form
    cpoInput.value = '';
    oerInput.value = '';
    shareInput.value = '';
    pkoInput.value = '';
    kerInput.value = '';
    unitInput.value = '1000';
    
    // Hide results
    results.classList.remove('show');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Focus first input
    cpoInput.focus();
  });

  // Focus first input on load
  cpoInput.focus();

  console.log('FFB Calculator initialized successfully');
});

// After initialization: add state mapping and image slider setup (separate IIFE)
(function postInit(){
  const stateSelect = document.getElementById('state');
  const shareInput = document.getElementById('share');
  if (!stateSelect || !shareInput) return;

  const stateShareMap = {
    'Andhra Pradesh':75,'Arunachal Pradesh':74,'Assam':74,'Bihar':73,'Chhattisgarh':74,'Goa':73,
    'Gujarat':73,'Haryana':74,'Himachal Pradesh':74,'Jharkhand':73,'Karnataka':75,'Kerala':75,
    'Madhya Pradesh':74,'Maharashtra':74,'Manipur':73,'Meghalaya':73,'Mizoram':73,'Nagaland':73,
    'Odisha':74,'Punjab':74,'Rajasthan':73,'Sikkim':73,'Tamil Nadu':75,'Telangana':75,'Tripura':74,
    'Uttar Pradesh':74,'Uttarakhand':74,'West Bengal':74,'Andaman and Nicobar Islands':73,'Chandigarh':73,
    'Dadra and Nagar Haveli and Daman and Diu':73,'Delhi':73,'Jammu and Kashmir':74,'Ladakh':74,'Lakshadweep':73,'Puducherry':73
  };

  stateSelect.addEventListener('change', function(){
    const s = stateSelect.value;
    const note = document.getElementById('shareNote');
    if (s && stateShareMap[s] !== undefined) {
      shareInput.value = stateShareMap[s];
      if (note) note.textContent = `Auto-filled recommended share for ${s}: ${stateShareMap[s]}% (editable)`;
    } else {
      if (note) note.textContent = 'Default values are provided as recommendations.';
    }
  });

  // Simple image slider initialization (fallback if CSS not enough)
  const slider = document.querySelector('.carousel');
  if (!slider) return;
  const track = slider.querySelector('.carousel-track');
  if (!track) return;

  // Duplicate track content to create a seamless infinite scroll
  // Only duplicate once to avoid huge DOM growth
  const imgs = track.querySelectorAll('.carousel-image');
  if (imgs.length > 0) {
    // clone nodes and append to track for looping effect
    const cloneHtml = track.innerHTML;
    track.innerHTML = track.innerHTML + cloneHtml;

    // Ensure the track height matches images
    track.style.alignItems = 'center';
    // Adjust animation duration based on number of images for smoother speed
    const totalImages = track.querySelectorAll('.carousel-image').length;
    const duration = Math.max(20, Math.min(40, totalImages * 3)); // seconds
    track.style.animation = `scroll ${duration}s linear infinite`;
  }
})();

/* ------------------------------------------------------------------- */
/* -------------------- 🌴 FFB Analysis Logic -------------------- */
/* ------------------------------------------------------------------- */

// Note: The original JS was wrapped in DOMContentLoaded.
// We are extracting the core logic and events for integration.

const calculatorForm = document.getElementById('calculatorForm');
if (calculatorForm) {
    const calculateBtn = document.getElementById('calculateBtn');
    const resetBtn = document.getElementById('resetBtn');
    const results = document.getElementById('results');
    const canvas = document.getElementById('priceChart');
    const ctx = canvas ? canvas.getContext('2d') : null;
    const pieCanvas = document.getElementById('sharePieChart');
    const pieCtx = pieCanvas ? pieCanvas.getContext('2d') : null;
    const DPR = window.devicePixelRatio || 1;

    function resizeCanvases() {
        if (!canvas || !pieCanvas) return;
        
        // Price Chart Resize
        const cssRect = canvas.getBoundingClientRect();
        const cssWidth = Math.max(320, Math.round(cssRect.width));
        const cssHeight = Math.max(200, Math.round(cssRect.height || 300));
        canvas.width = Math.round(cssWidth * DPR);
        canvas.height = Math.round(cssHeight * DPR);
        if (ctx) ctx.setTransform(DPR,0,0,DPR,0,0);

        // Pie Chart Resize
        const pRect = pieCanvas.getBoundingClientRect();
        const pW = Math.max(180, Math.round(pRect.width || 300));
        const pH = Math.max(180, Math.round(pRect.height || 300));
        pieCanvas.width = Math.round(pW * DPR);
        pieCanvas.height = Math.round(pH * DPR);
        if (pieCtx) pieCtx.setTransform(DPR,0,0,DPR,0,0);
    }

    // Initial resize after a tick so CSS has applied
    requestAnimationFrame(resizeCanvases);
    window.addEventListener('resize', resizeCanvases);
    window.addEventListener('orientationchange', () => setTimeout(resizeCanvases, 200));

    const farmerPriceEl = document.getElementById('farmerPrice');
    const oilContributionEl = document.getElementById('oilContribution');
    const kernelContributionEl = document.getElementById('kernelContribution');
    const advisoryListEl = document.getElementById('advisoryList');

    const cpoInput = document.getElementById('cpo');
    const oerInput = document.getElementById('oer');
    const shareInput = document.getElementById('share');
    const stateSelect = document.getElementById('state');
    const pkoInput = document.getElementById('pko');
    const kerInput = document.getElementById('ker');
    const unitInput = document.getElementById('unit');

    function calculateFFBPrice(cpo, oer, share, pko, ker, unit) {
        const oerDecimal = oer/100;
        const kerDecimal = ker/100;
        const shareDecimal = share/100;
        const oilValuePerKg = cpo * oerDecimal * shareDecimal;
        const kernelValuePerKg = pko * kerDecimal * shareDecimal;
        const pricePerKg = oilValuePerKg + kernelValuePerKg;
        const totalPrice = pricePerKg * unit;
        const oilContribution = oilValuePerKg * unit;
        const kernelContribution = kernelValuePerKg * unit;
        return { totalPrice, oilContribution, kernelContribution, pricePerKg };
    }

    function generateAdvisory(oer, share, ker, kernelContribution, unit) {
        const advisories = [];
        const push = (severity, title, details, action) => advisories.push({severity,title,details,action});
        if (oer < 16) push('high','Low OER','OER is below 16%. Improve irrigation and nutrition.','Check soil & fertilizer');
        else if (oer < 17.5) push('medium','Below-average OER','Slightly below target. Review harvesting maturity.','Review harvest timing');
        else push('low','Healthy OER','OER is good. Maintain practices.','Keep records');
        if (share < 70) push('high','Low Farmer Share','Under 70% - verify mill pricing.','Contact mill');
        else if (share < 75) push('medium','Average Farmer Share','Moderate share - compare mills.','Compare offers');
        else push('low','Good Farmer Share','Share percentage looks favourable.','Continue monitoring');
        if (ker < 3.5) push('medium','Low KER','KER below expected range.','Check maturity and processing');
        else push('low','Healthy KER','KER is within or above expected range.','Keep records');
        advisories.sort((a,b)=> (a.severity==='high'?0: a.severity==='medium'?1:2) - (b.severity==='high'?0: b.severity==='medium'?1:2));
        return advisories;
    }

    // Simple drawing helpers 
    function drawChart(oilValue, kernelValue, total, unit) {
        if (!ctx) return;
        ctx.clearRect(0,0,canvas.width/DPR, canvas.height/DPR);
        const padding = 28;
        const chartWidth = canvas.width/DPR - padding*2;
        const barHeight = 40;
        const spacing = 20;
        const maxValue = Math.max(total, 1);
        const oilW = (oilValue/maxValue) * chartWidth;
        const kerW = (kernelValue/maxValue) * chartWidth;

        ctx.font = 'bold 14px Segoe UI'; ctx.fillStyle = '#155724';
        ctx.fillText('Price Breakdown', padding, 22);

        // background bars
        ctx.fillStyle = '#e8f5e0'; roundRect(ctx, padding, 50, chartWidth, barHeight, 8); ctx.fill();
        ctx.fillStyle = '#fef3c7'; roundRect(ctx, padding, 50 + barHeight + spacing, chartWidth, barHeight, 8); ctx.fill();

        // oil
        const oilGrad = ctx.createLinearGradient(padding,0,padding+oilW,0); oilGrad.addColorStop(0,'#9bd36a'); oilGrad.addColorStop(1,'#5a8535');
        ctx.fillStyle = oilGrad; roundRect(ctx, padding, 50, oilW, barHeight, 8); ctx.fill();
        // kernel
        const kGrad = ctx.createLinearGradient(padding,0,padding+kerW,0); kGrad.addColorStop(0,'#ffd28a'); kGrad.addColorStop(1,'#d97706');
        ctx.fillStyle = kGrad; roundRect(ctx, padding, 50 + barHeight + spacing, kerW, barHeight, 8); ctx.fill();

        ctx.fillStyle = '#1a3d0f'; ctx.font = '13px Segoe UI'; ctx.fillText(`Oil: ₹${oilValue.toFixed(2)}`, padding + 8, 50 + 28);
        ctx.fillText(`Kernel: ₹${kernelValue.toFixed(2)}`, padding + 8, 50 + barHeight + spacing + 28);

        function roundRect(ctx,x,y,w,h,r){ if(w<=0) return; ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath(); }
    }

    function drawPieChart(oilValue, kernelValue){ 
        if (!pieCtx) return;
        pieCtx.clearRect(0,0,pieCanvas.width/DPR,pieCanvas.height/DPR); 
        const cx=(pieCanvas.width/DPR)/2, cy=(pieCanvas.height/DPR)/2, r=Math.min(cx,cy)-10; 
        const total=oilValue+kernelValue; 
        let start=-Math.PI/2; 
        const oAng = total>0?(oilValue/total)*Math.PI*2:0; 
        pieCtx.beginPath(); pieCtx.moveTo(cx,cy); 
        pieCtx.fillStyle='#73a942'; 
        pieCtx.arc(cx,cy,r,start,start+oAng); pieCtx.fill(); 
        pieCtx.beginPath(); pieCtx.moveTo(cx,cy); 
        pieCtx.fillStyle='#f59e0b'; 
        pieCtx.arc(cx,cy,r,start+oAng,start+oAng+((kernelValue/total)*Math.PI*2||0)); 
        pieCtx.fill(); 
        pieCtx.fillStyle='#1a3d0f'; pieCtx.font='12px Segoe UI'; pieCtx.textAlign='center'; 
        pieCtx.fillText(`Oil ₹${oilValue.toFixed(0)} • Kernel ₹${kernelValue.toFixed(0)}`, cx, cy+4); 
    }

    function validateInputs(){ 
        const cpo=parseFloat(cpoInput.value); 
        const oer=parseFloat(oerInput.value); 
        const share=parseFloat(shareInput.value); 
        const pko=parseFloat(pkoInput.value); 
        const ker=parseFloat(kerInput.value); 
        if(isNaN(cpo)||cpo<0){ alert('Please enter a valid CPO price'); cpoInput.focus(); return false;} 
        if(isNaN(oer)||oer<0||oer>100){ alert('Please enter a valid OER between 0 and 100'); oerInput.focus(); return false;} 
        if(isNaN(share)||share<0||share>100){ alert('Please enter a valid Farmer Share between 0 and 100'); shareInput.focus(); return false;} 
        if(isNaN(pko)||pko<0){ alert('Please enter a valid PKO price'); pkoInput.focus(); return false;} 
        if(isNaN(ker)||ker<0||ker>100){ alert('Please enter a valid KER between 0 and 100'); kerInput.focus(); return false;} 
        return true; 
    }

    calculateBtn.addEventListener('click', function(){ 
        if(!validateInputs()) return; 
        const cpo=parseFloat(cpoInput.value); 
        const oer=parseFloat(oerInput.value); 
        const share=parseFloat(shareInput.value); 
        const pko=parseFloat(pkoInput.value); 
        const ker=parseFloat(kerInput.value); 
        const unit=parseInt(unitInput.value);
        
        const res = calculateFFBPrice(cpo,oer,share,pko,ker,unit);
        const unitText = unit===1000?'/ton':'/kg'; 
        farmerPriceEl.textContent = `₹${res.totalPrice.toFixed(2)}${unitText}`; 
        oilContributionEl.textContent=`₹${res.oilContribution.toFixed(2)}`; 
        kernelContributionEl.textContent=`₹${res.kernelContribution.toFixed(2)}`;
        
        resizeCanvases(); 
        drawChart(res.oilContribution,res.kernelContribution,res.totalPrice,unit); 
        drawPieChart(res.oilContribution,res.kernelContribution);
        
        const advisories = generateAdvisory(oer,share,ker,res.kernelContribution,unit);
        advisoryListEl.innerHTML = advisories.map((adv,idx)=>
            `<li class="advisory-item severity-${adv.severity}" data-idx="${idx}">
                <div class="advisory-head"><strong>${adv.title}</strong><span class="advisory-action" data-idx="${idx}">Details</span></div>
                <div class="advisory-body" style="display:none">${adv.details}<br/><em>Recommended:</em> ${adv.action}</div>
            </li>`
        ).join('');
        
        advisoryListEl.querySelectorAll('.advisory-action').forEach(btn=>{ 
            btn.addEventListener('click', ()=>{ 
                const idx = btn.getAttribute('data-idx'); 
                const li = advisoryListEl.querySelector(`li[data-idx='${idx}']`); 
                if(!li) return; 
                const body = li.querySelector('.advisory-body'); 
                const visible = body.style.display !== 'none'; 
                body.style.display = visible ? 'none' : 'block'; 
                btn.textContent = visible ? 'Details' : 'Hide'; 
            }); 
        });
        
        // results.classList.add('show'); // Removed as results is always visible in this structure
        setTimeout(()=>{ 
            if (results) results.scrollIntoView({behavior:'smooth', block:'nearest'}); 
        }, 120);
    });

    resetBtn.addEventListener('click', function(){ 
        cpoInput.value=''; 
        oerInput.value=''; 
        shareInput.value=''; 
        pkoInput.value=''; 
        kerInput.value=''; 
        unitInput.value='1000'; 
        // results.classList.remove('show'); // Removed
        if (ctx) ctx.clearRect(0,0,canvas.width/DPR,canvas.height/DPR); 
        if (pieCtx) pieCtx.clearRect(0,0,pieCanvas.width/DPR,pieCanvas.height/DPR); 
        cpoInput.focus(); 
        advisoryListEl.innerHTML = ''; // Clear advisories
    });

    cpoInput.focus();

    // post init: state map logic (Self-executing function)
    const stateShareMap = { 
        'Andhra Pradesh':75,'Arunachal Pradesh':74,'Assam':74,'Bihar':73,'Chhattisgarh':74,'Goa':73,'Gujarat':73,'Haryana':74,'Himachal Pradesh':74,'Jharkhand':73,'Karnataka':75,'Kerala':75,'Madhya Pradesh':74,'Maharashtra':74,'Manipur':73,'Meghalaya':73,'Mizoram':73,'Nagaland':73,'Odisha':74,'Punjab':74,'Rajasthan':73,'Sikkim':73,'Tamil Nadu':75,'Telangana':75,'Tripura':74,'Uttar Pradesh':74,'Uttarakhand':74,'West Bengal':74,'Andaman and Nicobar Islands':73,'Chandigarh':73,'Dadra and Nagar Haveli and Daman and Diu':73,'Delhi':73,'Jammu and Kashmir':74,'Ladakh':74,'Lakshadweep':73,'Puducherry':73 
    };
    
    if(stateSelect && shareInput) { 
        stateSelect.addEventListener('change', function(){ 
            const s = stateSelect.value; 
            const note = document.getElementById('shareNote'); 
            if(s && stateShareMap[s] !== undefined){ 
                shareInput.value = stateShareMap[s]; 
                if(note) note.textContent = `Auto-filled recommended share for ${s}: ${stateShareMap[s]}% (editable)`; 
            } else { 
                if(note) note.textContent = 'Default values are provided as recommendations.'; 
            } 
        }); 
    } 
}

