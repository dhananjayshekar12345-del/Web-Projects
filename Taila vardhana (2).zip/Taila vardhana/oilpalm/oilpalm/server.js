require("dotenv").config();
const express = require("express");
const { GoogleGenAI } = require("@google/genai");
const cors = require("cors");
const path = require("path");
const http = require("http");
const { Server } = require("socket.io");

// App setup
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// Gemini AI initialization
const ai = new GoogleGenAI({});

const systemInstruction = `
You are the 'Seed Intel Assistant', a comprehensive agricultural expert for India.
Provide accurate, practical advice on oil palm, paddy, wheat, soil health, pests,
water management, finance (KCC), and mandi prices. Use simple farmer-friendly language.
`;

// ===========================================================
//                    CHAT ENDPOINT
// ===========================================================
app.post("/api/chat", async (req, res) => {
    const userMessage = req.body.message;

    if (!userMessage) {
        return res.status(400).json({ error: "Message content is required." });
    }

    try {
        const model = "gemini-2.5-flash";

        // STEP 1 — Detect language translation request
        const intentPrompt = `
        Analyze the user's message: "${userMessage}".
        Identify if they want translation.
        Output JSON:
        {
            "cleanPrompt": "core question",
            "targetLangCode": "hi-IN/mr-IN/te-IN or null"
        }
        `;

        let intentJson = { cleanPrompt: userMessage, targetLangCode: null };

        try {
            const intentResp = await ai.models.generateContent({
                model,
                contents: [{ parts: [{ text: intentPrompt }] }],
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: "OBJECT",
                        properties: {
                            cleanPrompt: { type: "STRING" },
                            targetLangCode: { type: "STRING" }
                        }
                    }
                }
            });

            const jsonText = intentResp.candidates?.[0]?.content?.parts?.[0]?.text;
            if (jsonText) intentJson = JSON.parse(jsonText);

        } catch (e) {
            console.warn("Translation intent detection failed. Continuing without translation.");
        }

        const cleanPrompt = intentJson.cleanPrompt || userMessage;
        const targetLangCode = intentJson.targetLangCode;

        // STEP 2 — Generate English response
        const englishResponseObj = await ai.models.generateContent({
            model,
            contents: [{ parts: [{ text: cleanPrompt }] }],
            config: {
                systemInstruction,
                temperature: 0.3
            }
        });

        const englishResponse =
            englishResponseObj.text || "Sorry, I couldn't generate a response.";

        let translatedText = null;

        // STEP 3 — Translate if needed
        if (targetLangCode && englishResponse) {
            const translationPrompt = `
            Translate to ${targetLangCode}. Respond ONLY with translated output.
            Text: "${englishResponse}"
            `;

            const translatedObj = await ai.models.generateContent({
                model,
                contents: [{ parts: [{ text: translationPrompt }] }],
                config: {
                    systemInstruction: { parts: [{ text: "Translate only. No extra text." }] }
                }
            });

            translatedText = translatedObj.text?.trim() || null;
        }

        res.json({
            englishResponse,
            translatedText,
            translatedLangCode: targetLangCode
        });

    } catch (error) {
        console.error("Gemini Error:", error);
        res.status(500).json({ error: "AI service failed." });
    }
});

// ===========================================================
//                    RISK ENDPOINT
// ===========================================================
app.post("/api/risk", (req, res) => {
    const addRisks = [
        "Consider regular mulching for best water retention.",
        "Check with local ag extension for fertilizer rates.",
        "Manage weeds well during the first 2 years.",
        "Apply compost to sandy soil for improved yield.",
        "Test soil pH before planting.",
        "Provide shade for seedlings during peak heat."
    ];

    let risks = [];
    if (Math.random() > 0.5) {
        risks.push(addRisks[Math.floor(Math.random() * addRisks.length)]);
    }

    res.json({ risks });
});

// ===========================================================
//             SOCKET.IO + HTTP SERVER (ONLY ONE)
// ===========================================================
const server = http.createServer(app);

const io = new Server(server, {
    cors: { origin: "*" }
});

let onlineUsers = 0;

io.on("connection", (socket) => {
    onlineUsers++;
    io.emit("onlineUsers", onlineUsers);

    socket.on("disconnect", () => {
        onlineUsers = Math.max(onlineUsers - 1, 0);
        io.emit("onlineUsers", onlineUsers);
    });
});

// FINAL — Only ONE listener → FIXES EADDRINUSE
server.listen(port, () => {
    console.log(`Backend + Socket.IO running at http://localhost:${port}`);
});
