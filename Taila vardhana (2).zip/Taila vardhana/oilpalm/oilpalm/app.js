// app.js — Plant Health Check App

const fileInput = document.getElementById('fileInput');
const videoEl = document.getElementById('video');
const previewImg = document.getElementById('previewImg');
const previewPlaceholder = document.getElementById('previewPlaceholder');
const startCameraBtn = document.getElementById('startCamera');
const stopCameraBtn = document.getElementById('stopCamera');
const captureBtn = document.getElementById('captureBtn');
const analyzeBtn = document.getElementById('analyzeBtn');
const resetBtn = document.getElementById('resetBtn');
const modelStatus = document.getElementById('modelStatus');
const bgCarousel = document.getElementById('bgCarousel');

const predLabel = document.getElementById('predLabel');
const predConfidence = document.getElementById('predConfidence');
const predRecommendation = document.getElementById('predRecommendation');
const advisoryBox = document.getElementById('advisoryBox');
const advisoryContent = document.getElementById('advisoryContent');

let stream = null;
let model = null;

// Point to the training model located at the repository root `model/` folder
// Path from this file (oilpalm/oilpalm) to the repo `model/` is '../../model/'
const MODEL_PATH = '../../model/';

const oerValue = document.getElementById('oerValue');
const oerRing = document.getElementById('oerRing');
const oerGuide = document.getElementById('oerGuide');

// Recommendations mapping
const recommendations = {
  'Magnesium Deficiency': 'Consider magnesium-rich fertilizer and check soil pH.',
  'Dryness': 'Increase watering and check soil moisture.',
  'Fungal Disease': 'Remove affected leaves and consider fungicide.',
  'scale insect': 'Try neem oil or insecticidal soap.'
};

function calculateOER(confidence) {
  const minOER = 9.0;
  const maxOER = 16.0;
  const mapped = minOER + (confidence / 100) * (maxOER - minOER);
  return Math.round(mapped * 10) / 10;
}

function updateOERVisualization(oer) {
  const angle = (oer / 100) * 360;
  if (oerRing) {
    oerRing.style.background = `conic-gradient(var(--green) 0deg, var(--green) ${angle}deg, #e8e8e8 ${angle}deg, #e8e8e8 360deg)`;
  }
  if (oerValue) oerValue.textContent = oer;
}

const advisoryDetails = {
  // … (unchanged – KEEP EVERYTHING)
  'Magnesium Deficiency': {
    severity: 'Medium',
    actions: [
      'Apply magnesium sulfate (Epsom salt) solution every 2 weeks',
      'Check soil pH (should be 6.0-7.0)',
      'Ensure proper drainage',
      'Use balanced fertilizer with micronutrients'
    ],
    oerGuidance: 'Magnesium deficiency reduces oil content quality. Expected OER improvement: +15-25% after nutrient correction.'
  },
  'Dryness': {
    severity: 'High',
    actions: [
      'Water immediately to saturate soil',
      'Increase watering frequency based on season',
      'Improve drainage to prevent waterlogging',
      'Add mulch to retain soil moisture',
      'Monitor humidity levels'
    ],
    oerGuidance: 'Dehydration severely impacts oil extraction. Immediate hydration essential. Expected OER recovery: +25-40% with proper irrigation.'
  },
  'Fungal Disease': {
    severity: 'Critical',
    actions: [
      'Remove infected leaves immediately',
      'Improve air circulation around plant',
      'Avoid overhead watering',
      'Apply fungicide spray if severe',
      'Isolate plant from other plants',
      'Clean tools before handling other plants'
    ],
    oerGuidance: 'Fungal infection drastically reduces oil viability. Critical treatment needed before extraction. Recovery potential: +40-50% with successful treatment.'
  },
  'scale insect': {
    severity: 'Medium',
    actions: [
      'Spray with neem oil or insecticidal soap',
      'Remove affected branches if possible',
      'Isolate infested plant',
      'Repeat treatment every 7-10 days',
      'Monitor nearby plants for spread',
      'Maintain plant health to prevent reinfestation'
    ],
    oerGuidance: 'Scale insects damage oil-producing tissues. Pest elimination crucial. Expected OER restoration: +15-20% after infestation control.'
  }
};

// Background slides
function loadBackgroundImages() {
  const images = ['img/bg.jpg', 'img/bg2.jpg', 'img/bg3.jpg', 'img/bg4.jpg'];
  images.forEach((imgPath, i) => {
    const slide = document.createElement('div');
    slide.className = 'bg-slide';
    slide.style.backgroundImage = `url('${imgPath}')`;
    slide.style.left = `${i * 100}%`;
    bgCarousel.appendChild(slide);
  });
}
loadBackgroundImages();

function checkAnalyzeEnable() {
  analyzeBtn.disabled = !model || !previewImg.src;
}

function showPreviewImg(dataUrl) {
  previewImg.src = dataUrl;
  previewImg.classList.remove('hidden');
  videoEl.classList.add('hidden');
  previewPlaceholder.classList.add('hidden');
  checkAnalyzeEnable();
}

function clearPreview() {
  previewImg.src = '';
  previewImg.classList.add('hidden');
  videoEl.classList.add('hidden');
  previewPlaceholder.classList.remove('hidden');
  predLabel.textContent = '—';
  predConfidence.textContent = '—';
  predRecommendation.textContent = 'No prediction yet. Upload or capture an image to analyze.';
  advisoryBox.style.display = 'none';
  if (oerValue) oerValue.textContent = '0';
  if (oerRing) oerRing.style.background = 'conic-gradient(var(--green) 0deg, var(--green) 0deg, #e8e8e8 0deg, #e8e8e8 360deg)';
  checkAnalyzeEnable();
}

// MODEL INIT
async function initModel() {
  try {
    modelStatus.textContent = 'Loading model…';
    model = await tmImage.load(MODEL_PATH + 'model.json', MODEL_PATH + 'metadata.json');
    modelStatus.textContent = 'Model ready ✓';
    checkAnalyzeEnable();
  } catch (err) {
    modelStatus.textContent = 'Model failed to load';
    console.error(err);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initModel);
} else {
  initModel();
}

// FILE INPUT
fileInput.addEventListener('change', (e) => {
  const f = e.target.files[0];
  if (!f) return clearPreview();
  showPreviewImg(URL.createObjectURL(f));
});

// CAMERA (UNCHANGED LOGIC)
startCameraBtn.addEventListener('click', async () => {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video:true });
    videoEl.srcObject = stream;
    videoEl.classList.remove('hidden');
    previewImg.classList.add('hidden');
    previewPlaceholder.classList.add('hidden');
    stopCameraBtn.disabled = false;
    captureBtn.disabled = false;
    startCameraBtn.disabled = true;
    analyzeBtn.disabled = true;
  } catch (err) {
    alert('Camera error');
  }
});

stopCameraBtn.addEventListener('click', () => {
  if (stream) {
    stream.getTracks().forEach(t => t.stop());
    stream = null;
  }
  videoEl.srcObject = null;
  videoEl.classList.add('hidden');
  stopCameraBtn.disabled = true;
  captureBtn.disabled = true;
  startCameraBtn.disabled = false;
});

captureBtn.addEventListener('click', () => {
  if (!stream) return;
  const canvas = document.createElement('canvas');
  canvas.width = videoEl.videoWidth || 640;
  canvas.height = videoEl.videoHeight || 480;
  canvas.getContext('2d').drawImage(videoEl, 0, 0);
  const dataUrl = canvas.toDataURL('image/jpeg');
  if (stream) {
    stream.getTracks().forEach(t => t.stop());
    stream = null;
  }
  videoEl.srcObject = null;
  videoEl.classList.add('hidden');
  startCameraBtn.disabled = false;
  stopCameraBtn.disabled = true;
  captureBtn.disabled = true;
  showPreviewImg(dataUrl);
});

// RESET
resetBtn.addEventListener('click', () => {
  clearPreview();
  if (stream) {
    stream.getTracks().forEach(t => t.stop());
    stream = null;
  }
  videoEl.srcObject = null;
});

// PREDICTION
async function runPrediction() {
  if (!previewImg.src) return alert('Upload or capture image');
  if (!model) return alert('Model still loading');

  analyzeBtn.disabled = true;
  analyzeBtn.textContent = '⏳ Analyzing...';

  const img = previewImg;

  if (img.complete && img.naturalWidth !== 0) {
    doPrediction(img);
  } else {
    img.onload = () => doPrediction(img);
  }
}

async function doPrediction(img) {
  try {
    const predictions = await model.predict(img, false);
    predictions.sort((a,b)=>b.probability - a.probability);
    const top = predictions[0];
    const label = top.className.trim();
    const conf = Math.round(top.probability * 100);

    predLabel.textContent = label;
    predConfidence.textContent = conf + '%';

    let rec = recommendations[label] || 'No recommendation.';
    if(conf < 60) rec += ' (Low confidence – try better lighting)';
    predRecommendation.textContent = rec;

    const details = advisoryDetails[label];
    if (details) {
      advisoryContent.innerHTML = `
        <div style="margin-bottom:8px;font-weight:600;">
          Severity: ${details.severity}
        </div>
        <ul>${details.actions.map(a=>`<li>${a}</li>`).join('')}</ul>
      `;
      advisoryBox.style.display = 'block';
    } else {
      advisoryBox.style.display = 'none';
    }

    const oer = calculateOER(conf);
    updateOERVisualization(oer);

  } catch (err) {
    predLabel.textContent = 'Error';
    console.error(err);
  } finally {
    analyzeBtn.disabled = false;
    analyzeBtn.textContent = '🔍 Analyze Plant';
  }
}

// Wire
analyzeBtn.addEventListener('click', runPrediction);

// Final init
clearPreview();
