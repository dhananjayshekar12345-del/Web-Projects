// --------------------
// SUPABASE CONNECTION
// --------------------
const SUPABASE_URL = "https://hbbkvkdcfneraygvvqxf.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhiYmt2a2RjZm5lcmF5Z3Z2cXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUyNzEyMzYsImV4cCI6MjA4MDg0NzIzNn0.kxcSZA_0XZNLmoviYzb5vmeujyQwCaJgIEnbekvTBKQ";

const db = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// -----------------------------
// FETCH & DISPLAY ALL STORIES
// -----------------------------
async function loadStories() {
  const container = document.getElementById("stories-container");
  
  if (!container) {
    console.error("Error: stories-container element not found!");
    return;
  }

  container.innerHTML = "<p>Loading stories...</p>";

  try {
    const { data, error } = await db
      .from("stories")
      .select("*");

    if (error) {
      console.error("Supabase error:", error);
      container.innerHTML = `<p style="color: red;">Error loading stories: ${error.message}</p>`;
      return;
    }

    if (!data || data.length === 0) {
      container.innerHTML = "<p>No stories found in the database.</p>";
      return;
    }

    console.log("Stories loaded:", data.length);
    container.innerHTML = ""; // clear existing

    data.forEach((story) => {
      const card = document.createElement("div");
      card.className = "story-card";

      const shortText = story.story ? story.story.substring(0, 150) + "..." : "No story text available";
      const imageUrl = story.image_url || 'https://via.placeholder.com/300x210/538d22/ffffff?text=Farmer+Story';

      card.innerHTML = `
        <img src="${imageUrl}" class="story-image" onerror="this.src='https://via.placeholder.com/300x210/538d22/ffffff?text=Farmer+Story'" />

        <div class="story-title">${story.name || 'Unknown'}</div>
        <div class="story-state">${story.state || 'Unknown'}</div>

        <div class="story-text" id="text-${story.id}">
          ${shortText}
        </div>

        <div class="read-more" id="btn-${story.id}">
          Read More
        </div>
      `;

      container.appendChild(card);

      // Add event listener instead of inline onclick
      document.getElementById(`btn-${story.id}`).addEventListener('click', () => {
        toggleStory(story.id, story.story);
      });
    });
  } catch (err) {
    console.error("Unexpected error:", err);
    container.innerHTML = `<p style="color: red;">Unexpected error: ${err.message}</p>`;
  }
}

loadStories();

// -----------------------------
// TOGGLE READ MORE
// -----------------------------
function toggleStory(id, fullText) {
  const textBlock = document.getElementById(`text-${id}`);
  const button = document.getElementById(`btn-${id}`);

  if (textBlock.dataset.expanded === "true") {
    textBlock.textContent = fullText.substring(0, 150) + "...";
    textBlock.dataset.expanded = "false";
    button.textContent = "Read More";
  } else {
    textBlock.textContent = fullText;
    textBlock.dataset.expanded = "true";
    button.textContent = "Show Less";
  }
}
