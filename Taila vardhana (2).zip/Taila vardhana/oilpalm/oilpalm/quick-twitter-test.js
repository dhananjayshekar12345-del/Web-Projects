require('dotenv').config();
const { TwitterApi } = require('twitter-api-v2');

(async () => {
  const {
    TWITTER_APP_KEY,
    TWITTER_APP_SECRET,
    TWITTER_ACCESS_TOKEN,
    TWITTER_ACCESS_SECRET
  } = process.env;

  if (!TWITTER_APP_KEY || !TWITTER_APP_SECRET || !TWITTER_ACCESS_TOKEN || !TWITTER_ACCESS_SECRET) {
    console.error('Missing Twitter credentials in .env. Fill TWITTER_APP_KEY, TWITTER_APP_SECRET, TWITTER_ACCESS_TOKEN, TWITTER_ACCESS_SECRET.');
    process.exit(1);
  }

  try {
    const client = new TwitterApi({
      appKey: TWITTER_APP_KEY,
      appSecret: TWITTER_APP_SECRET,
      accessToken: TWITTER_ACCESS_TOKEN,
      accessSecret: TWITTER_ACCESS_SECRET
    }).readWrite;

    const text = `Test tweet from local script at ${new Date().toISOString()}`;
    console.log('Posting tweet:', text);
    const response = await client.v2.tweet(text);
    const id = response && (response.data ? response.data.id : response.id);
    console.log('Posted. Tweet URL:', id ? `https://twitter.com/i/status/${id}` : '(no id returned)');
  } catch (err) {
    console.error('Error posting tweet (redact secrets before sharing):', err.message || err);
    if (err.response && err.response.data) console.error('API response data:', JSON.stringify(err.response.data));
    process.exit(1);
  }
})();