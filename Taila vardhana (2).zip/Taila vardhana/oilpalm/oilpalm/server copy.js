/**
 * server.js
 * - Handles farmer reports (file uploads), admin dashboard, grouping and tweeting.
 * - Simple admin login issues a short-lived token (in-memory, demo-only).
 * - Twitter posting supports multiple credential sets and will queue failed tweets to retry.
 *
 * Dependencies: express, multer, nodemailer, cors, twitter-api-v2, dotenv
 * Install: npm install express multer nodemailer cors twitter-api-v2 dotenv
 *
 * Usage:
 * - Create a .env (see .env.example).
 * - node server.js
 */
require('dotenv').config();
const express = require('express');
const multer = require('multer');
const nodemailer = require('nodemailer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { TwitterApi } = require('twitter-api-v2');

const PORT = process.env.PORT || 3000;
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR);

const upload = multer({ dest: UPLOADS_DIR });
const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOADS_DIR));

// Simple in-memory stores (demo). You can switch to a DB easily later.
let problemReports = [];
let reportIdCounter = 1;
const TWEET_QUEUE_FILE = path.join(__dirname, 'tweetQueue.json');
let tweetQueue = [];

// Load seeded reports if present
const seedPath = path.join(__dirname, 'problemReports.json');
if (fs.existsSync(seedPath)) {
  try {
    const raw = fs.readFileSync(seedPath, 'utf8');
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      problemReports = parsed.map(r => ({ ...r }));
      reportIdCounter = Math.max(1, ...problemReports.map(p => p.id || 0) + 1);
      console.log(`Loaded ${problemReports.length} seeded reports`);
    }
  } catch (e) {
    console.error('Failed to load problemReports.json', e);
  }
}

// Load queue
function loadQueue() {
  if (fs.existsSync(TWEET_QUEUE_FILE)) {
    try {
      tweetQueue = JSON.parse(fs.readFileSync(TWEET_QUEUE_FILE, 'utf8'));
      console.log(`Loaded ${tweetQueue.length} queued tweet(s)`);
    } catch (e) {
      console.error('Failed to parse tweetQueue.json, starting empty', e);
      tweetQueue = [];
    }
  } else {
    tweetQueue = [];
  }
}
function saveQueue() {
  try {
    fs.writeFileSync(TWEET_QUEUE_FILE, JSON.stringify(tweetQueue, null, 2));
  } catch (e) {
    console.error('Failed to save tweet queue:', e);
  }
}
loadQueue();

// --- Admin auth (simple token) ---
const adminTokens = new Map(); // token -> expiry timestamp
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'password';
const TOKEN_TTL_MS = 1000 * 60 * 60; // 1 hour

function generateToken() {
  return crypto.randomBytes(24).toString('hex');
}

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization || '';
  const m = auth.match(/^Bearer (.+)$/);
  if (!m) return res.status(401).json({ success: false, message: 'Missing Authorization header' });
  const token = m[1];
  const expiry = adminTokens.get(token);
  if (!expiry || expiry < Date.now()) {
    adminTokens.delete(token);
    return res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
  // refresh token expiry on use (optional)
  adminTokens.set(token, Date.now() + TOKEN_TTL_MS);
  req.adminToken = token;
  next();
}

// --- Twitter clients and posting helpers ---
function buildTwitterClientsFromEnv() {
  const clients = [];
  const sets = [
    { key: 'TWITTER_APP_KEY', secret: 'TWITTER_APP_SECRET', token: 'TWITTER_ACCESS_TOKEN', accessSecret: 'TWITTER_ACCESS_SECRET' },
    { key: 'TWITTER_APP_KEY_2', secret: 'TWITTER_APP_SECRET_2', token: 'TWITTER_ACCESS_TOKEN_2', accessSecret: 'TWITTER_ACCESS_SECRET_2' },
    { key: 'TWITTER_APP_KEY_3', secret: 'TWITTER_APP_SECRET_3', token: 'TWITTER_ACCESS_TOKEN_3', accessSecret: 'TWITTER_ACCESS_SECRET_3' },
  ];

  for (const s of sets) {
    const appKey = process.env[s.key];
    const appSecret = process.env[s.secret];
    const accessToken = process.env[s.token];
    const accessSecret = process.env[s.accessSecret];
    if (appKey && appSecret && accessToken && accessSecret) {
      try {
        const client = new TwitterApi({
          appKey, appSecret, accessToken, accessSecret
        }).readWrite;
        clients.push({ client, id: s.key });
      } catch (e) {
        console.warn(`Could not init twitter client for ${s.key}:`, e && e.message);
      }
    }
  }
  console.log(`Initialized ${clients.length} Twitter client(s)`);
  return clients;
}
let twitterClients = buildTwitterClientsFromEnv();

async function tryPostWithClients(tweetText) {
  if (!twitterClients || twitterClients.length === 0) {
    return { success: false, reason: 'no_client', message: 'No Twitter clients configured.' };
  }
  let lastErr = null;
  for (const entry of twitterClients) {
    try {
      const resp = await entry.client.v2.tweet(tweetText);
      const id = resp && (resp.data ? resp.data.id : resp.id);
      return { success: true, url: id ? `https://twitter.com/i/status/${id}` : null, clientId: entry.id, raw: resp };
    } catch (err) {
      let status = null;
      try { status = err.response && err.response.status; } catch (e) {}
      lastErr = err;
      console.warn(`Client ${entry.id} failed posting (status=${status}), trying next if any`);
      // continue to next client for rate limit or auth or other errors
      continue;
    }
  }
  return { success: false, reason: 'all_failed', message: 'All Twitter clients failed', error: lastErr };
}

// Queueing and retry worker
const RETRY_INTERVAL_MS = 2 * 60 * 1000; // every 2 minutes
const MAX_RETRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

async function processQueueOnce() {
  if (!tweetQueue.length) return;
  const now = Date.now();
  let changed = false;
  for (const item of [...tweetQueue]) {
    if (item.nextAttemptAt && item.nextAttemptAt > now) continue;
    if (item.retryUntil && now > item.retryUntil) {
      console.warn(`Dropping tweet ${item.id} after retryUntil`);
      tweetQueue = tweetQueue.filter(t => t.id !== item.id);
      changed = true;
      continue;
    }
    console.log(`Retrying queued tweet ${item.id} (attempt ${item.attempts + 1})`);
    const res = await tryPostWithClients(item.tweetText);
    if (res.success) {
      console.log(`Queued tweet ${item.id} posted via ${res.clientId}: ${res.url}`);
      tweetQueue = tweetQueue.filter(t => t.id !== item.id);
      changed = true;
    } else {
      item.attempts = (item.attempts || 0) + 1;
      item.lastError = res.message || (res.error && (res.error.message || String(res.error))) || 'unknown';
      const backoff = Math.min(60*60*1000 * Math.pow(2, item.attempts - 1), 24*60*60*1000);
      item.nextAttemptAt = Date.now() + backoff;
      console.log(`Queued tweet ${item.id} next attempt at ${new Date(item.nextAttemptAt).toISOString()}`);
      changed = true;
    }
  }
  if (changed) saveQueue();
}
setInterval(processQueueOnce, RETRY_INTERVAL_MS);
processQueueOnce().catch(e => console.error('Initial queue process error:', e));

// Utility: enqueue
function enqueueTweet(tweetText, meta) {
  const id = 'q-' + Date.now() + '-' + Math.floor(Math.random()*1000);
  const now = Date.now();
  const item = {
    id,
    tweetText,
    meta: meta || {},
    createdAt: now,
    retryUntil: now + MAX_RETRY_MS,
    attempts: 0,
    nextAttemptAt: now + 60*1000 // first retry after 1 minute
  };
  tweetQueue.push(item);
  saveQueue();
  return item;
}

// --- Endpoints ---

// Admin login
app.post('/admin/login', (req, res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    const token = generateToken();
    adminTokens.set(token, Date.now() + TOKEN_TTL_MS);
    return res.json({ success: true, token, expiresIn: TOKEN_TTL_MS });
  }
  return res.status(401).json({ success: false, message: 'Invalid credentials' });
});

// Farmer report submission (accept any file fields)
app.post('/report', upload.any(), async (req, res) => {
  try {
    const { name, state, description, issue_category, voice_language, phone } = req.body;
    const f = (req.files || []).map(x => ({ filename: x.filename, originalname: x.originalname, mimetype: x.mimetype }));
    const r = {
      id: reportIdCounter++,
      farmer_name: name || 'Unknown',
      state: state || 'Unknown',
      phone: phone || 'N/A',
      problem_text: description || '',
      issue_category: issue_category || 'Unspecified',
      voice_language: voice_language || 'N/A',
      date: new Date().toISOString().split('T')[0],
      files: f
    };
    problemReports.push(r);

    // Send notification email (best-effort)
    if (process.env.RECIPIENT_EMAIL && process.env.SENDER_EMAIL && process.env.SENDER_PASSWORD) {
      try {
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: { user: process.env.SENDER_EMAIL, pass: process.env.SENDER_PASSWORD }
        });
        const attachments = (req.files || []).map(file => ({ filename: file.originalname, path: path.join(UPLOADS_DIR, file.filename) }));
        await transporter.sendMail({
          to: process.env.RECIPIENT_EMAIL,
          from: process.env.SENDER_EMAIL,
          subject: `New Report: ${r.issue_category} (${r.state})`,
          text: `Farmer: ${r.farmer_name}\nPhone: ${r.phone}\nState: ${r.state}\nCategory: ${r.issue_category}\n\n${r.problem_text}`,
          attachments
        }).catch(e => console.error('Email send error (non-fatal):', e));
      } catch (e) {
        console.error('Email transport setup failed:', e);
      }
    } else {
      console.log('Email not configured, skipping send.');
    }

    // Persist (optional) - we leave problemReports in memory but you can write to disk if desired
    res.json({ success: true, message: 'Report submitted', reportId: r.id });
  } catch (err) {
    console.error('report error:', err);
    res.status(500).json({ success: false, message: 'Server error submitting report.' });
  }
});

// Public (or admin) fetch reports - frontend uses Authorization but it's optional
app.get('/api/reports', (req, res) => {
  try {
    const out = [...problemReports].sort((a,b) => b.id - a.id);
    res.json(out);
  } catch (err) {
    console.error('/api/reports error:', err);
    res.status(500).json({ success: false, message: 'Server error retrieving reports.' });
  }
});

// Delete report (admin only)
app.delete('/api/reports/:id', authMiddleware, (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const idx = problemReports.findIndex(p => p.id === id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Report not found' });
    const rep = problemReports[idx];
    // delete associated files
    (rep.files || []).forEach(f => {
      const p = path.join(UPLOADS_DIR, f.filename);
      if (fs.existsSync(p)) {
        try { fs.unlinkSync(p); } catch (e) { console.error('unlink error', e); }
      }
    });
    problemReports.splice(idx, 1);
    return res.json({ success: true, message: `Report ${id} deleted` });
  } catch (e) {
    console.error('delete report error', e);
    res.status(500).json({ success: false, message: 'Server error deleting report.' });
  }
});

// Group & Tweet (admin only)
app.post('/api/admin/group-and-tweet', authMiddleware, async (req, res) => {
  try {
    const { reports, issueIdToTweet, tweetNow } = req.body || {};
    const reportsToAnalyze = (reports && Array.isArray(reports) && reports.length) ? reports : problemReports;
    if (!reportsToAnalyze || reportsToAnalyze.length === 0) {
      return res.json({ success: true, action: 'grouping', message: 'No reports to analyze', groupedIssues: [] });
    }

    // Simple grouping logic - same as before
    const grouped = (function group(reps) {
      const map = reps.reduce((acc, r) => {
        const cat = r.issue_category || 'Unspecified';
        if (!acc[cat]) acc[cat] = { reports: [], states: new Set(), farmers: new Set(), count: 0 };
        if (r.farmer_name) acc[cat].farmers.add(r.farmer_name);
        if (r.state) acc[cat].states.add(r.state);
        acc[cat].reports.push(r);
        acc[cat].count++;
        return acc;
      }, {});
      return Object.keys(map).map((k, i) => {
        const d = map[k];
        const farmers = Array.from(d.farmers).slice(0,3);
        const states = Array.from(d.states).slice(0,3);
        const stateAbbr = states.map(s => (s || '').substring(0,2).toUpperCase()).join(', ');
        let tweet_text = `URGENT: ${k} hitting ${d.count} farms in ${stateAbbr} (${d.states.size} states). Reported by ${farmers.join(', ')} & others.`;
        if (tweet_text.length > 240) tweet_text = `URGENT: ${k} in ${stateAbbr}. ${d.count} reports.`;
        return { id: i+1, issue: k, states, farmers, count: d.count, tweet_text };
      });
    })(reportsToAnalyze);

    // If only grouping requested
    if (!issueIdToTweet && !tweetNow) {
      return res.json({ success: true, action: 'grouping', groupedIssues: grouped });
    }

    // Find the issue to tweet
    const issueToTweet = grouped.find(g => g.id === issueIdToTweet) || grouped[0];
    if (!issueToTweet) {
      return res.status(404).json({ success: false, message: 'No issue found to tweet', groupedIssues: grouped });
    }

    const tweetText = issueToTweet.tweet_text;
    // Try to post now
    const postResult = await tryPostWithClients(tweetText);
    if (postResult.success) {
      return res.json({ success: true, action: 'tweeting', message: 'Tweet posted', tweetUrl: postResult.url, groupedIssues: grouped });
    }

    // If posting failed, enqueue for retry and return generated tweet_text & mock URL
    const queued = enqueueTweet(tweetText, { generatedFor: issueToTweet.issue });
    return res.json({
      success: false,
      action: 'tweeting',
      message: 'Tweet could not be posted now; queued for retry.',
      tweet_text: tweetText,
      mock_tweet_url: `https://example.com/mock-tweet/${queued.id || queued.id}`,
      groupedIssues: grouped
    });

  } catch (err) {
    console.error('group-and-tweet error:', err);
    return res.status(500).json({ success: false, message: 'Server error during grouping/tweeting.', error: err.message });
  }
});

// Admin view queue
app.get('/api/admin/queue', authMiddleware, (req, res) => {
  res.json({ queued: tweetQueue.length, items: tweetQueue });
});

// Dev helper: debug reports including file existence (admin)
app.get('/api/admin/debug-reports', authMiddleware, (req, res) => {
  try {
    const reportsWithFiles = (problemReports || []).map(r => {
      const files = (r.files || []).map(f => {
        const filePath = path.join(UPLOADS_DIR, f.filename || '');
        return { filename: f.filename, originalname: f.originalname, exists: fs.existsSync(filePath) };
      });
      return { ...r, files };
    });
    res.json({ success: true, reports: reportsWithFiles });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

// Health
app.get('/_health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Twitter clients configured: ${twitterClients.length}`);
});